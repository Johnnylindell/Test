(function (root) {
'use strict';
function normalizeUrl(value) {
  if (typeof value !== 'string') return '';
  var raw = value.trim();
  if (!raw) return '';
  if (!/^https?:\/\//i.test(raw)) raw = 'https://' + raw;
  try { var u = new URL(raw); return (/^https?:$/.test(u.protocol) && u.hostname) ? u.href : ''; } catch (_e) { return ''; }
}
function toSearchString(item) {return [item.title,item.url,item.category,item.description].join(' ').toLocaleLowerCase();}
function searchEntries(entries, query, category, favorites, recent) {
  var q = String(query||'').trim().toLocaleLowerCase();
  return entries.filter(function(item) {
    if (category === 'favorites' && !favorites.includes(item.url)) return false;
    if (category === 'recent' && !recent.includes(item.url)) return false;
    if (category !== 'all' && category !== 'favorites' && category !== 'recent' && item.category !== category) return false;
    return !q || toSearchString(item).indexOf(q)!==-1;
  }).sort(function(a,b){
    if(category === 'recent')return recent.indexOf(a.url)-recent.indexOf(b.url);
    return a.title.localeCompare(b.title,'sv');
  });
}
function formatTime(seconds) {
  if (!isFinite(seconds)||seconds<0)return '00:00';
  var t=Math.floor(seconds), s=String(t%60).padStart(2,'0'),m=Math.floor(t/60);
  return m>=60?Math.floor(m/60)+':'+String(m%60).padStart(2,'0')+':'+s:String(m).padStart(2,'0')+':'+s;
}
var api={normalizeUrl:normalizeUrl, searchEntries:searchEntries, formatTime:formatTime};
if(typeof module==='object'&&module.exports)module.exports=api;
else root.VideoCastLogic=api;
})(this);
