"use strict";
window.VIDEOCAST_CATALOG = [
  {
    "title": "Cinejoy",
    "url": "https://cinejoy.to/",
    "category": "Stream Aggregators",
    "description": "Stream Aggregators"
  },
  {
    "title": "PopcornMovies",
    "url": "https://popcornmovies.io/",
    "category": "Stream Aggregators",
    "description": "Stream Aggregators"
  },
  {
    "title": "Rive",
    "url": "https://www.rivestream.app/",
    "category": "Stream Aggregators",
    "description": "Stream Aggregators"
  },
  {
    "title": "CorsFlix",
    "url": "https://watch.corsflix.net/",
    "category": "Stream Aggregators",
    "description": "Stream Aggregators"
  },
  {
    "title": "7Movies",
    "url": "https://7movies.in/",
    "category": "Stream Aggregators",
    "description": "Stream Aggregators"
  },
  {
    "title": "ShuttleTV",
    "url": "https://shuttletv.su/",
    "category": "Stream Aggregators",
    "description": "Stream Aggregators"
  },
  {
    "title": "Vivarium",
    "url": "https://vivarium.wtf/",
    "category": "Stream Aggregators",
    "description": "Stream Aggregators"
  },
  {
    "title": "FlyStream",
    "url": "https://flystream.net/",
    "category": "Stream Aggregators",
    "description": "Stream Aggregators"
  },
  {
    "title": "Aether",
    "url": "https://aether.bar/",
    "category": "P-Stream Forks",
    "description": "P-Stream Forks"
  },
  {
    "title": "Basement",
    "url": "https://basementx.xyz/",
    "category": "P-Stream Forks",
    "description": "P-Stream Forks"
  },
  {
    "title": "StreamWatch",
    "url": "https://streamwatch.online/",
    "category": "P-Stream Forks",
    "description": "P-Stream Forks"
  },
  {
    "title": "IceFY",
    "url": "https://icefy.top/",
    "category": "P-Stream Forks",
    "description": "P-Stream Forks"
  },
  {
    "title": "NEPU",
    "url": "https://nepu.to/",
    "category": "Dedicated-Server",
    "description": "Dedicated-Server"
  },
  {
    "title": "Streaming Unity",
    "url": "https://streamingunity.dog/",
    "category": "Dedicated-Server",
    "description": "Dedicated-Server"
  },
  {
    "title": "AniCine",
    "url": "https://anicine.xyz/",
    "category": "Multi-Server",
    "description": "Multi-Server"
  },
  {
    "title": "Tubi",
    "url": "https://tubitv.com/",
    "category": "Free w/ Ads",
    "description": "Free w/ Ads"
  },
  {
    "title": "Plex",
    "url": "https://watch.plex.tv/",
    "category": "Free w/ Ads",
    "description": "Free w/ Ads"
  },
  {
    "title": "Pluto TV",
    "url": "https://pluto.tv/",
    "category": "Free w/ Ads",
    "description": "Free w/ Ads"
  },
  {
    "title": "ARTE",
    "url": "https://www.arte.tv/",
    "category": "Free w/ Ads",
    "description": "Free w/ Ads"
  },
  {
    "title": "Filmzie",
    "url": "https://filmzie.com/",
    "category": "Free w/ Ads",
    "description": "Free w/ Ads"
  },
  {
    "title": "JustWatch",
    "url": "https://www.justwatch.com/",
    "category": "Free w/ Ads",
    "description": "Free w/ Ads"
  },
  {
    "title": "YouTube",
    "url": "https://www.youtube.com/",
    "category": "Video Streaming",
    "description": "Video Streaming"
  },
  {
    "title": "Vimeo",
    "url": "https://vimeo.com/",
    "category": "Video Streaming",
    "description": "Video Streaming"
  },
  {
    "title": "Dailymotion",
    "url": "https://www.dailymotion.com/",
    "category": "Video Streaming",
    "description": "Video Streaming"
  },
  {
    "title": "PeerTube",
    "url": "https://joinpeertube.org/",
    "category": "Video Streaming",
    "description": "Video Streaming"
  },
  {
    "title": "Odysee",
    "url": "https://odysee.com/",
    "category": "Video Streaming",
    "description": "Video Streaming"
  },
  {
    "title": "Short of the Week",
    "url": "https://www.shortoftheweek.com/",
    "category": "Specialty Streaming",
    "description": "Specialty Streaming"
  },
  {
    "title": "Le Cinéma Club",
    "url": "https://www.lecinemaclub.com/",
    "category": "Specialty Streaming",
    "description": "Specialty Streaming"
  },
  {
    "title": "Internet Archive",
    "url": "https://archive.org/details/movies",
    "category": "Specialty Streaming",
    "description": "Specialty Streaming"
  },
  {
    "title": "Prelinger Archives",
    "url": "https://archive.org/details/prelinger",
    "category": "Specialty Streaming",
    "description": "Specialty Streaming"
  },
  {
    "title": "EverythingMoe",
    "url": "https://everythingmoe.com/",
    "category": "Anime Streaming",
    "description": "Anime Streaming"
  },
  {
    "title": "Wotaku",
    "url": "https://wotaku.wiki/",
    "category": "Anime Streaming",
    "description": "Anime Streaming"
  },
  {
    "title": "Adult Swim",
    "url": "https://www.adultswim.com/videos/",
    "category": "TV Streaming",
    "description": "TV Streaming"
  },
  {
    "title": "HISTORY",
    "url": "https://www.history.com/shows/",
    "category": "TV Streaming",
    "description": "TV Streaming"
  },
  {
    "title": "Red Bull TV",
    "url": "https://www.redbull.com/int-en/discover",
    "category": "TV Streaming",
    "description": "TV Streaming"
  },
  {
    "title": "Pluto TV",
    "url": "https://pluto.tv/",
    "category": "Live TV / Sports",
    "description": "Live TV / Sports"
  },
  {
    "title": "Red Bull TV",
    "url": "https://www.redbull.com/int-en/discover",
    "category": "Live TV / Sports",
    "description": "Live TV / Sports"
  },
  {
    "title": "SVT Play",
    "url": "https://www.svtplay.se/",
    "category": "Public service",
    "description": "TV-vänlig kataloglänk"
  },
  {
    "title": "YLE Arenan",
    "url": "https://arenan.yle.fi/",
    "category": "Public service",
    "description": "TV-vänlig kataloglänk"
  }
];
