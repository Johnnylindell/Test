(function(){'use strict';
var $=function(id){return document.getElementById(id);};
var Logic=window.VideoCastLogic;
var catalog=(window.VIDEOCAST_CATALOG||[]).slice();
var favs=readStore('videocast:favorites',[]), recent=readStore('videocast:recent',[]), extra=readStore('videocast:custom',[]);
var activeFilter='all', mode='home', currentSite=null, beforePlayer='home', modalOpen=false;
var video=$('video'), toastTimer=null, currentFrameTimeout=null;
var title=$('catalogTitle'), grid=$('catalogGrid'), query=$('catalogQuery');
catalog=catalog.concat(extra);
function readStore(k,fallback){try{var v=JSON.parse(localStorage.getItem(k));return Array.isArray(v)?v:fallback;}catch(e){return fallback;}}
function writeStore(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
function text(el,value){el.textContent=String(value||'');}
function message(m){var el=$('toast');text(el,m);el.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(function(){el.classList.remove('visible');},4500);}
function setMode(m){mode=m;$('homeView').classList.toggle('hidden',m!=='home');$('sidebar').classList.toggle('hidden',m!=='home');$('siteView').classList.toggle('hidden',m!=='site');$('playerView').classList.toggle('hidden',m!=='player');}
function categories(){var c=[];catalog.forEach(function(s){if(c.indexOf(s.category)<0)c.push(s.category);});c.sort();return c;}
function categoryName(f){return f==='all'?'Alla webbplatser':f==='favorites'?'Favoriter':f==='recent'?'Senast besökta':f;}
function redrawCategories(){var nav=$('categoryNavigation');nav.textContent='';categories().forEach(function(cat){var b=document.createElement('button');b.className='nav';b.type='button';b.dataset.filter=cat;text(b,cat);nav.appendChild(b);});highlightNavigation();}
function highlightNavigation(){document.querySelectorAll('[data-filter]').forEach(function(btn){btn.classList.toggle('active',btn.dataset.filter===activeFilter);});}
function redrawCatalog(){
  var entries=Logic.searchEntries(catalog,query.value,activeFilter,favs,recent);
  text(title,categoryName(activeFilter));text($('catalogCount'),entries.length+' webbplatser');grid.textContent='';
  entries.forEach(function(site){
    var b=document.createElement('div');b.className='card';b.tabIndex=0;b.setAttribute('role','button');b.setAttribute('aria-label','Öppna '+site.title);
    var h=document.createElement('div');h.className='card-name';text(h,site.title);
    var cat=document.createElement('div');cat.className='card-category';text(cat,site.category);
    var host=document.createElement('div');host.className='card-url';try{text(host,new URL(site.url).hostname);}catch(e){text(host,site.url);}
    var star=document.createElement('button');star.type='button';star.className='favorite'+(favs.indexOf(site.url)>=0?' checked':'');text(star,favs.indexOf(site.url)>=0?'★':'☆');star.setAttribute('aria-label','Favorit '+site.title);
    star.addEventListener('click',function(e){e.stopPropagation();if(favs.indexOf(site.url)>=0)favs=favs.filter(function(x){return x!==site.url;});else favs.push(site.url);writeStore('videocast:favorites',favs);redrawCatalog();});
    b.appendChild(h);b.appendChild(cat);b.appendChild(host);b.appendChild(star);
    b.addEventListener('click',function(){openSite(site);});b.addEventListener('keydown',function(e){if(e.key==='Enter'){e.stopPropagation();openSite(site);}});
    grid.appendChild(b);
  });
  $('emptyState').classList.toggle('hidden',entries.length>0);
}
function openSite(site){currentSite=site;recent=recent.filter(function(x){return x!==site.url;});recent.unshift(site.url);recent=recent.slice(0,30);writeStore('videocast:recent',recent);text($('siteName'),site.title);text($('siteAddress'),site.url);setMode('site');var f=$('siteFrame');f.src='about:blank';f.src=site.url;clearTimeout(currentFrameTimeout);currentFrameTimeout=setTimeout(function(){if(mode==='site')message('Om webbplatsen är tom: välj "Öppna i LG-webbläsaren".');},5000);$('siteBrowser').focus();}
function launchBrowser(){var url=currentSite&&currentSite.url;if(!url)return;var failed=function(){message('Kunde inte öppna TV-webbläsaren. Kontrollera att din webOS-modell stöder detta.');};
  if(window.webOSDev&&window.webOSDev.launch&&window.webOSDev.APP&&window.webOSDev.APP.BROWSER){window.webOSDev.launch({id:window.webOSDev.APP.BROWSER,params:{target:url},onFailure:failed});return;}
  if(window.webOS&&window.webOS.service){window.webOS.service.request('luna://com.webos.applicationManager',{method:'launch',parameters:{id:'com.webos.app.browser',params:{target:url}},onFailure:failed});return;}
  var w=window.open(url,'_blank');if(!w)failed();
}
function goHome(){if(mode==='site'){$('siteFrame').src='about:blank';}setMode('home');redrawCatalog();$('catalogQuery').focus();}
function showPlayer(){beforePlayer=mode;setMode('player');$('videoUrl').focus();}
function leavePlayer(){video.pause();setMode(beforePlayer==='site'?'site':'home');if(mode==='site')$('siteBrowser').focus();else $('catalogQuery').focus();}
function loadVideo(){var u=Logic.normalizeUrl($('videoUrl').value);if(!u){message('Ange en giltig http(s)-adress till en videoström.');return;}video.pause();video.removeAttribute('src');video.querySelectorAll('track').forEach(function(t){t.remove();});video.load();$('playerOverlay').classList.add('hidden');video.src=u;video.load();var p=video.play();if(p&&p.catch)p.catch(function(){message('Uppspelning kunde inte startas. Tryck Play eller välj annan ström.');});}
function togglePlayback(){if(video.paused){var p=video.play();if(p&&p.catch)p.catch(function(){message('Uppspelning stöds inte av TV:n.');});}else video.pause();}
function seek(delta){if(isFinite(video.duration)&&video.duration>0)video.currentTime=Math.min(video.duration,Math.max(0,video.currentTime+delta));}
function updatePosition(){text($('positionText'),Logic.formatTime(video.currentTime));text($('durationText'),Logic.formatTime(video.duration));if(isFinite(video.duration)&&video.duration>0)$('seekBar').value=Math.round(video.currentTime/video.duration*1000);}
function refreshSubtitles(){var area=$('subtitleOptions');area.textContent='';var off=document.createElement('button');off.type='button';off.className='button dim';text(off,'Av');off.onclick=function(){for(var i=0;i<video.textTracks.length;i++)video.textTracks[i].mode='disabled';closeSubs();};area.appendChild(off);for(var i=0;i<video.textTracks.length;i++){(function(index){var track=video.textTracks[index];var btn=document.createElement('button');btn.type='button';btn.className='button dim';text(btn,track.label||track.language||'Spår '+(index+1));btn.onclick=function(){for(var j=0;j<video.textTracks.length;j++)video.textTracks[j].mode=j===index?'showing':'disabled';closeSubs();};area.appendChild(btn);})(i);}if(video.textTracks.length===0){var tip=document.createElement('span');text(tip,'Inga undertexter hittades i strömmen. Lägg till extern WebVTT om det finns.');area.appendChild(tip);}}
function closeSubs(){$('subtitleModal').classList.add('hidden');modalOpen=false;$('subtitleButton').focus();}
function addSubtitle(){var u=Logic.normalizeUrl($('subtitleUrl').value);if(!u||!(/\.vtt([?#]|$)/i.test(u))){message('Ange en WebVTT-länk som slutar med .vtt.');return;}var t=document.createElement('track');t.kind='subtitles';t.label='Extern';t.srclang='sv';t.src=u;video.appendChild(t);refreshSubtitles();message('Undertext tillagd. Om den inte visas kan servern neka åtkomst (CORS).');}
function addSite(){var title=prompt('Webbplatsens namn?');if(!title)return;var url=Logic.normalizeUrl(prompt('Webbadress (https://...)')||'');if(!url){message('Ogiltig webbadress.');return;}if(catalog.some(function(x){return x.url===url;})){message('Webbplatsen finns redan.');return;}var site={title:title.slice(0,70),url:url,category:'Egna länkar',description:'Tillagd på TV:n'};extra.push(site);catalog.push(site);writeStore('videocast:custom',extra);redrawCategories();activeFilter='all';query.value='';highlightNavigation();redrawCatalog();message('Webbplats tillagd.');}
function goBack(){if(modalOpen){closeSubs();return;}if(mode==='player'){leavePlayer();return;}if(mode==='site'){goHome();return;}if(activeFilter!=='all'||query.value){activeFilter='all';query.value='';highlightNavigation();redrawCatalog();$('catalogQuery').focus();return;}if(window.webOS&&window.webOS.platformBack)window.webOS.platformBack();else message('Tryck Home på fjärrkontrollen för att lämna appen.');}
function spatialKey(e){var list=Array.prototype.slice.call(document.querySelectorAll('button,input,.card[tabindex]')).filter(function(el){return !!(el.offsetWidth&&el.offsetHeight&&!el.disabled);});var el=document.activeElement;if(!el||list.indexOf(el)<0){(list[0]||{}).focus&&list[0].focus();return;}var key=e.keyCode||e.which;if((key===37||key===39)&&(el.tagName==='INPUT')&&el.type!=='range')return;if(key===37||key===39||key===38||key===40){if(el.type==='range')return;e.preventDefault();var a=el.getBoundingClientRect(),ax=a.left+a.width/2,ay=a.top+a.height/2,dir=key===37?'left':key===39?'right':key===38?'up':'down',best=null,bestScore=Infinity;list.forEach(function(b){if(b===el)return;var r=b.getBoundingClientRect(),dx=(r.left+r.width/2)-ax,dy=(r.top+r.height/2)-ay;if(dir==='left'&&dx>=-4||dir==='right'&&dx<=4||dir==='up'&&dy>=-4||dir==='down'&&dy<=4)return;var dist=(dir==='left'||dir==='right')?Math.abs(dx)+Math.abs(dy)*2.1:Math.abs(dy)+Math.abs(dx)*2.1;if(dist<bestScore){best=b;bestScore=dist;}});if(best){best.focus();best.scrollIntoView({block:'nearest'});}}}
function setup(){redrawCategories();redrawCatalog();
 document.addEventListener('click',function(e){var b=e.target.closest('[data-filter]');if(!b)return;activeFilter=b.dataset.filter;highlightNavigation();redrawCatalog();$('catalogTitle').scrollIntoView({block:'nearest'});});
 $('catalogQuery').addEventListener('input',redrawCatalog);$('searchButton').onclick=function(){redrawCatalog();};$('addSiteButton').onclick=addSite;
 $('openPlayerTop').onclick=showPlayer;$('siteBack').onclick=goHome;$('siteBrowser').onclick=launchBrowser;$('siteFallback').onclick=launchBrowser;
 $('siteReload').onclick=function(){if(currentSite)$('siteFrame').src=currentSite.url;};
 $('playerBack').onclick=leavePlayer;$('loadVideo').onclick=loadVideo;$('playPause').onclick=togglePlayback;$('seekBack').onclick=function(){seek(-10);};$('seekForward').onclick=function(){seek(30);};
 $('seekBar').onchange=function(){if(isFinite(video.duration)&&video.duration>0)video.currentTime=(Number(this.value)||0)*video.duration/1000;};
 $('subtitleButton').onclick=function(){refreshSubtitles();$('subtitleModal').classList.remove('hidden');modalOpen=true;$('closeSubtitle').focus();};$('closeSubtitle').onclick=closeSubs;$('addSubtitle').onclick=addSubtitle;
 video.addEventListener('timeupdate',updatePosition);video.addEventListener('loadedmetadata',updatePosition);video.addEventListener('ended',updatePosition);
 video.addEventListener('error',function(){var m='TV:n kunde inte spela strömmen. Prova en annan källa, eller kontrollera codec och åtkomst.';text($('playerNotice'),m);message(m);});
 document.addEventListener('keydown',function(e){var code=e.keyCode||e.which;if(code===461||code===27||e.key==='Escape'){e.preventDefault();goBack();return;}if(mode==='player'&&(code===415||code===19||code===413)){e.preventDefault();if(code===413)video.pause();else togglePlayback();return;}spatialKey(e);});
 $('catalogQuery').focus();
 document.addEventListener('webOSLaunch',function(e){try{var p=e.detail&&e.detail.params||{};if(p.mediaUrl){showPlayer();$('videoUrl').value=p.mediaUrl;loadVideo();}}catch(err){}});
}
setup();
})();
