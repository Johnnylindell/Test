// Placeholder for official webOSTV.js, bundled by GitHub Actions build from webOS CLI's basic template.
// In a normal desktop browser, UI and local catalog still work without it.
