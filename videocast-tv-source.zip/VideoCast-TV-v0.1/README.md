# Video Cast TV 0.1 – fristående LG webOS-app

## Vad den gör

Denna app kan öppnas direkt på LG-TV:n **utan mobilen**. Den ger en fjärrkontrollvänlig TV-katalog med webbplatser hämtade från den tidigare Video Cast/FMHY-katalogen plus några öppna videotjänster. Du kan söka **webbplatser/kategorier**, bläddra, skapa favoriter, se senast besökta och lägga till egna webbplatsadresser. När du öppnar en webbplats kan du försöka använda den i den inbyggda inramade vyn; om webbplatsen blockerar inbäddning kan du starta TV:ns officiella webbläsare direkt med en knapp. Där använder du webbplatsens **egen film- och seriesökning**, precis som i mobilappens webbvy.

Inbyggd direktströmsspelare: öppna en vanlig HTTPS-videolänk, pausa/spola och välj eventuella undertextspår (eller lägg till en extern WebVTT-länk). Videon avkodas med de format/codecs som TV-modellen redan stöder; detta paket lägger **inte** till en fristående FFmpeg-dekoder och kan inte kringgå DRM, CORS, inloggningar eller anti-hotlink.

## Begränsningar

- Sökfältet söker bland **webbplatserna**, inte i alla film- och serieindex. Varje webbplats kan ha en egen sökruta när den öppnas. Generell sökning över andra webbplatsers kataloger kräver officiella API:er eller separat indexering som inte ingår.
- Andra webbplatser kan blockera `<iframe>` med X-Frame-Options/CSP. Då är **Öppna i LG-webbläsaren** det avsedda alternativet. Den externa webbläsaren har egna popup- och uppspelningsregler.
- TV-webbappen kan inte fånga upp alla ström-URL:er inuti andra domäners iframe på grund av same-origin-skyddet. För den inbyggda direktströmsspelaren måste strömmens URL vara känd/tillgänglig.
- Webbsidan som öppnas kan behöva Magic Remote-pekaren, inte bara pilknapparna.
- Funktionstest på fysisk LG-TV återstår. Kompatibilitet beror på TV-modell och webOS-version.
- Använd tjänster och material som du har tillåtelse att titta på.

## Installera `.ipk` i utvecklarläge

1. På LG-TV:n: installera **Developer Mode** från LG Content Store (om tillgängligt på din modell). Logga in på ett kostnadsfritt LG Developer-konto, aktivera Dev Mode och slå på Key Server enligt LG:s instruktioner.
2. På datorn: installera Node.js och `npm install -g @webos-tools/cli`. Ställ in profil: `ares-config --profile tv`.
3. Kör `ares-setup-device` och lägg till din TV:s IP-adress, port `9922` och användarnamn `prisoner`.
4. Kör `ares-novacom --device myTV --getkey` och ange lösenfrasen från TV:ns Developer Mode-app.
5. Installera: `ares-install -d myTV com.videocast.tv_0.1.0_all.ipk` (anpassa filvägen).
6. Starta: `ares-launch -d myTV com.videocast.tv`. Appen ska också synas i TV:ns launcher så länge utvecklarläget är aktivt.

LG:s steg: https://webostv.developer.lge.com/develop/getting-started/developer-mode-app

## Bygg själv

```sh
node tests/catalog.test.js
npm install --no-save @webos-tools/cli@3.2.6
# Kopiera webOSTV.js från det officiella CLI-paketets basic-template till app/webOSTV.js
npx ares-package --no-minify -o dist ./app
```

GitHub Actions-workflowet gör detta automatiskt och publicerar en `.ipk` under Artifacts.

## Senare integration med Android

Mobilappen fungerar fortsatt separat som LG/Chromecast-castklient. Denna TV-app behöver den inte. Att få Android-appen att starta **just TV-appen** med en videolänk kräver att vi bygger en separat mottagar-/parkopplingslösning eller en stödd webOS startparameterintegration; det ingår inte i 0.1.
