package com.example.lgembeddedcast;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class SubtitleTrackTest {
    @Test public void detectsVttAndTtmlButNotJavascriptOrBlob() {
        assertTrue(SubtitleTrack.from("https://video.example/cc/sv.vtt?token=x","","Svenska","sv-SE","").externalCastReady());
        assertTrue(SubtitleTrack.from("https://video.example/cc/en","application/ttml+xml","English","en","").externalCastReady());
        assertNull(SubtitleTrack.from("blob:https://video.example/1","text/vtt","", "", ""));
        assertNull(SubtitleTrack.from("javascript:alert(1)","text/vtt","", "", ""));
        assertFalse(SubtitleTrack.from("https://video.example/cc/de.srt","","German","de","").externalCastReady());
    }
    @Test public void parsesQuotedCommasAndRelativePathsFromHlsMaster() {
        String manifest="#EXTM3U\n#EXT-X-VERSION:4\n" +
            "#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=audio,NAME=English,URI=audio.m3u8\n" +
            "#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID=subs,NAME=\"Svenska, SDH\",LANGUAGE=sv,URI=\"../subs/sv.m3u8\"\n" +
            "#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID=subs,NAME=English,LANGUAGE=en,URI=english.m3u8\n";
        List<SubtitleTrack> result=HlsSubtitleParser.parse("https://cdn.example/stream/master.m3u8",manifest);
        assertEquals(2,result.size());
        assertEquals("https://cdn.example/subs/sv.m3u8",result.get(0).url);
        assertEquals("Svenska, SDH",result.get(0).label);
        assertEquals("sv",result.get(0).language);
        assertEquals(SubtitleTrack.Format.HLS,result.get(0).format);
    }
    @Test public void rejectsInvalidManifest() {
        assertTrue(HlsSubtitleParser.parse("https://test.example/a.m3u8", "<html>not a manifest</html>").isEmpty());
    }
}
