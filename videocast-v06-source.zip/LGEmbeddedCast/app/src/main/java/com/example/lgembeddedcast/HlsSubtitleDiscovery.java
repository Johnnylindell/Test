package com.example.lgembeddedcast;

import android.os.Handler;
import android.os.Looper;

import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/** Reads a small publicly accessible HLS manifest; never forwards browser cookies or auth headers. */
public final class HlsSubtitleDiscovery {
    public interface Listener { void onTracks(String sourceUrl, List<SubtitleTrack> tracks); }
    private final OkHttpClient client = new OkHttpClient.Builder().connectTimeout(6,TimeUnit.SECONDS)
            .readTimeout(6,TimeUnit.SECONDS).followRedirects(true).build();
    private final Handler main = new Handler(Looper.getMainLooper());
    public void scan(String url, Listener listener) {
        new Thread(() -> {
            try {
                Request request = new Request.Builder().url(url).header("Accept", "application/vnd.apple.mpegurl,*/*").get().build();
                try (Response response = client.newCall(request).execute()) {
                    if (!response.isSuccessful() || response.body() == null) return;
                    try (InputStream stream = response.body().byteStream()) {
                        byte[] buf=new byte[8192]; int size,total=0;
                        ByteArrayOutputStream out=new ByteArrayOutputStream();
                        while ((size=stream.read(buf))!=-1 && total<400_000) {
                            out.write(buf,0,Math.min(size,400_000-total));total+=size;
                        }
                        List<SubtitleTrack> found=HlsSubtitleParser.parse(response.request().url().toString(),
                                out.toString(StandardCharsets.UTF_8.name()));
                        if (!found.isEmpty()) main.post(() -> listener.onTracks(url,found));
                    }
                }
            } catch (Exception ignored) { /* auth-bound and inaccessible manifests are not castable directly */ }
        },"hls-subtitles").start();
    }
}
