package com.example.lgembeddedcast;

import android.content.Context;

import androidx.mediarouter.app.MediaRouteButton;

import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.MediaTrack;
import com.google.android.gms.cast.TextTrackStyle;
import com.google.android.gms.cast.framework.CastButtonFactory;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManager;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

/** CAF sender with live caption selection. Captions must be accessible to Chromecast directly. */
public final class ChromecastController {
    public interface Listener {
        void onSessionReady();
        void onSessionEnded();
        void onStatus(String message);
        void onSubtitleTracksChanged();
    }

    public static final class CaptionOption {
        public final long id;
        public final String label;
        public final String language;
        public final String contentId;
        CaptionOption(MediaTrack track) {
            id = track.getId();
            label = track.getName() == null || track.getName().trim().isEmpty()
                    ? (track.getLanguage() == null ? "Undertext" : track.getLanguage()) : track.getName();
            language = track.getLanguage() == null ? "" : track.getLanguage();
            contentId = track.getContentId() == null ? "" : track.getContentId();
        }
        public String displayName() {
            return label + (language.isEmpty() || language.equalsIgnoreCase(label) ? "" : " (" + language + ")");
        }
    }

    private final Listener listener;
    private final Context context;
    private final SessionManager sessionManager;
    private RemoteMediaClient listeningClient;
    private String waitingSubtitleKey;
    private final RemoteMediaClient.Callback statusCallback = new RemoteMediaClient.Callback() {
        @Override public void onStatusUpdated() {
            listener.onSubtitleTracksChanged();
            if (waitingSubtitleKey != null) {
                String key = waitingSubtitleKey;
                // Only select once it is present on the remote; HLS tracks arrive after load.
                if (selectFromRemote(key, false)) waitingSubtitleKey = null;
            }
        }
    };
    private final SessionManagerListener<CastSession> sessionListener = new SessionManagerListener<CastSession>() {
        @Override public void onSessionStarting(CastSession session) { listener.onStatus("Ansluter till Chromecast …"); }
        @Override public void onSessionStarted(CastSession session, String id) { listenTo(session); listener.onSessionReady(); }
        @Override public void onSessionStartFailed(CastSession session, int error) {
            listener.onStatus("Chromecast-anslutningen misslyckades (" + error + ").");
            listener.onSessionEnded();
        }
        @Override public void onSessionSuspended(CastSession session, int reason) { listener.onStatus("Chromecast-anslutningen avbröts."); }
        @Override public void onSessionResuming(CastSession session, String id) { }
        @Override public void onSessionResumed(CastSession session, boolean suspended) { listenTo(session); listener.onSessionReady(); }
        @Override public void onSessionResumeFailed(CastSession session, int error) { listener.onStatus("Kunde inte återansluta till Chromecast."); listener.onSessionEnded(); }
        @Override public void onSessionEnding(CastSession session) { }
        @Override public void onSessionEnded(CastSession session, int error) {
            unlisten(); waitingSubtitleKey = null; listener.onSessionEnded();
        }
    };

    public ChromecastController(Context context, MediaRouteButton button, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        CastContext castContext = CastContext.getSharedInstance(context);
        sessionManager = castContext.getSessionManager();
        CastButtonFactory.setUpMediaRouteButton(context.getApplicationContext(), button);
        sessionManager.addSessionManagerListener(sessionListener, CastSession.class);
        listenTo(sessionManager.getCurrentCastSession());
    }

    private void listenTo(CastSession session) {
        RemoteMediaClient next = session == null ? null : session.getRemoteMediaClient();
        if (next == listeningClient) return;
        unlisten();
        if (next != null) { listeningClient = next; next.registerCallback(statusCallback); }
    }
    private void unlisten() {
        if (listeningClient != null) { listeningClient.unregisterCallback(statusCallback); listeningClient = null; }
    }

    public boolean isConnected() {
        CastSession session = sessionManager.getCurrentCastSession();
        return session != null && session.isConnected() && session.getRemoteMediaClient() != null;
    }

    public List<CaptionOption> availableSubtitles() {
        RemoteMediaClient client = client();
        if (client == null || client.getMediaInfo() == null || client.getMediaInfo().getMediaTracks() == null)
            return Collections.emptyList();
        List<CaptionOption> result = new ArrayList<>();
        for (MediaTrack track : client.getMediaInfo().getMediaTracks()) {
            if (track.getType() == MediaTrack.TYPE_TEXT) result.add(new CaptionOption(track));
        }
        return result;
    }

    /** Select a subtitle identified by media track ID, without restarting the video. */
    public void selectSubtitleId(long trackId) {
        RemoteMediaClient client = client();
        if (client == null) { listener.onStatus("Anslut till Chromecast först."); return; }
        boolean known = trackId == -1;
        for (CaptionOption option : availableSubtitles()) if (option.id == trackId) known = true;
        if (!known) { listener.onStatus("Undertextspåret är inte längre tillgängligt."); return; }
        waitingSubtitleKey = null;
        client.setActiveMediaTracks(trackId == -1 ? new long[0] : new long[]{trackId})
                .setResultCallback(result -> listener.onStatus(result.getStatus().isSuccess()
                        ? (trackId == -1 ? "Undertexter avstängda." : "Undertext aktiverad på Chromecast.")
                        : "Chromecast kunde inte byta undertext: " + result.getStatus().getStatusMessage()));
    }

    /** If the receiver already knows this page subtitle, activate it immediately. */
    public boolean selectFromRemote(String key, boolean showError) {
        for (CaptionOption option : availableSubtitles()) {
            if (!option.contentId.isEmpty() && option.contentId.equals(key)) {
                selectSubtitleId(option.id); return true;
            }
        }
        if (showError) listener.onStatus("Textspåret finns inte i pågående uppspelning. Ladda om videon med undertext.");
        return false;
    }

    public boolean selectManifestSubtitle(SubtitleTrack subtitle) {
        for (CaptionOption option : availableSubtitles()) {
            // Native HLS/DASH captions are discovered by the receiver; URL is not always exposed.
            if (option.contentId.equals(subtitle.url) || !subtitle.language.isEmpty() &&
                    (subtitle.language.equalsIgnoreCase(option.language) ||
                     option.language.toLowerCase(Locale.ROOT).startsWith(subtitle.language.toLowerCase(Locale.ROOT) + "-")) ||
                    option.label.equalsIgnoreCase(subtitle.label)) {
                selectSubtitleId(option.id); return true;
            }
        }
        listener.onStatus("TV:n har inte publicerat det här HLS-textspåret. Prova TV:ns undertextmeny.");
        return false;
    }

    public long currentPosition() {
        RemoteMediaClient remote = client();
        if (remote == null || !remote.hasMediaSession() || remote.isLiveStream()) return 0;
        return Math.max(0, remote.getApproximateStreamPosition());
    }

    public boolean cast(VideoCandidate video) { return cast(video, Collections.emptyList(), null, 0); }

    /** Reload the currently cast title with external WebVTT/TTML tracks, preserving the playhead. */
    public boolean cast(VideoCandidate video, List<SubtitleTrack> tracks, String preferredKey, long resumeMs) {
        if (video.kind == VideoCandidate.Kind.YOUTUBE) {
            listener.onStatus("En YouTube-inbäddning är ingen direkt Cast-videolänk. Använd YouTubes Cast-knapp.");
            return false;
        }
        RemoteMediaClient client = client();
        if (client == null) { listener.onStatus("Anslut till Chromecast först."); return false; }
        String mime;
        switch (video.kind) {
            case HLS: mime = "application/vnd.apple.mpegurl"; break;
            case DASH: mime = "application/dash+xml"; break;
            case MPEG_TS: mime = "video/mp2t"; break;
            case MKV: listener.onStatus("Chromecast standardmottagare stöder inte MKV."); return false;
            case WEBM: mime = "video/webm"; break;
            case MP4:
            default: mime = "video/mp4"; break;
        }
        List<MediaTrack> castTracks = new ArrayList<>();
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        if (tracks != null) {
            for (SubtitleTrack track : tracks) {
                if (track.externalCastReady() && seen.add(track.key()) && castTracks.size() < 20) {
                    long id = 10000L + castTracks.size();
                    castTracks.add(new MediaTrack.Builder(id, MediaTrack.TYPE_TEXT)
                            .setName(track.label).setSubtype(MediaTrack.SUBTYPE_SUBTITLES)
                            .setLanguage(track.language.isEmpty() ? "und" : track.language)
                            .setContentId(track.url).setContentType(track.mimeType()).build());
                }
            }
        }
        MediaMetadata metadata = new MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE);
        metadata.putString(MediaMetadata.KEY_TITLE, video.title);
        MediaInfo.Builder info = new MediaInfo.Builder(video.url)
                .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
                .setContentType(mime).setMetadata(metadata);
        if (!castTracks.isEmpty()) info.setMediaTracks(castTracks);
        MediaLoadRequestData.Builder load = new MediaLoadRequestData.Builder()
                .setMediaInfo(info.build()).setAutoplay(true);
        if (resumeMs > 0) load.setCurrentTime(resumeMs);
        if (preferredKey != null) {
            for (MediaTrack track : castTracks) {
                if (preferredKey.equals(track.getContentId())) {
                    load.setActiveTrackIds(new long[]{track.getId()}); break;
                }
            }
            waitingSubtitleKey = preferredKey;
        } else waitingSubtitleKey = null;
        try {
            client.load(load.build()).setResultCallback(result -> listener.onStatus(result.getStatus().isSuccess()
                    ? "Videon skickades till Chromecast" + (preferredKey == null ? "." : " med valt undertextspår.")
                    : "Chromecast kunde inte starta videon: " + result.getStatus().getStatusMessage()));
            return true;
        } catch (Exception e) {
            listener.onStatus("Chromecast-fel: " + e.getMessage()); return false;
        }
    }

    public void playback(String action) {
        RemoteMediaClient client = client();
        if (client == null) { listener.onStatus("Ingen aktiv Chromecast-session."); return; }
        try {
            if ("Play".equals(action)) client.play();
            else if ("Pause".equals(action)) client.pause();
            else if ("Stop".equals(action)) client.stop();
        } catch (Exception e) { listener.onStatus("Chromecast-fel: " + e.getMessage()); }
    }

    private RemoteMediaClient client() {
        CastSession session = sessionManager.getCurrentCastSession();
        return session == null || !session.isConnected() ? null : session.getRemoteMediaClient();
    }

    public void close() {
        unlisten();
        sessionManager.removeSessionManagerListener(sessionListener, CastSession.class);
        // Leave the Cast session running when the phone UI closes.
    }
}
