package com.example.lgembeddedcast;

import java.net.URI;
import java.util.Locale;
import java.util.regex.Pattern;

/** A public subtitle URL discovered in an embedded player or an adaptive manifest. */
public final class SubtitleTrack {
    public enum Format { WEBVTT, TTML, SRT, HLS, UNKNOWN }
    private static final Pattern LANGUAGE = Pattern.compile("(?i)^[a-z]{2,3}(-[a-z0-9]{2,8})*$");
    public final String url;
    public final String label;
    public final String language;
    public final String pageUrl;
    public final Format format;
    public final boolean fromManifest;

    private SubtitleTrack(String url, String label, String language, String pageUrl,
                          Format format, boolean fromManifest) {
        this.url = url;
        this.label = label;
        this.language = language;
        this.pageUrl = pageUrl == null ? "" : pageUrl;
        this.format = format;
        this.fromManifest = fromManifest;
    }

    public static SubtitleTrack from(String url, String mimeHint, String label,
                                     String language, String pageUrl) {
        return build(url, mimeHint, label, language, pageUrl, false);
    }

    public static SubtitleTrack fromManifest(String url, String label, String language, String pageUrl) {
        return build(url, "application/vnd.apple.mpegurl", label, language, pageUrl, true);
    }

    private static SubtitleTrack build(String rawUrl, String mimeHint, String label,
                                       String language, String pageUrl, boolean manifest) {
        if (rawUrl == null || rawUrl.length() > 8192) return null;
        try {
            URI uri = new URI(rawUrl.trim());
            if (uri.getScheme() == null || !("http".equalsIgnoreCase(uri.getScheme()) || "https".equalsIgnoreCase(uri.getScheme()))
                    || uri.getHost() == null || uri.getUserInfo() != null) return null;
            String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
            String mime = mimeHint == null ? "" : mimeHint.toLowerCase(Locale.ROOT);
            Format f;
            if (manifest || path.endsWith(".m3u8") && mime.contains("mpegurl")) f = Format.HLS;
            else if (path.endsWith(".vtt") || mime.contains("text/vtt") || mime.contains("webvtt")) f = Format.WEBVTT;
            else if (path.endsWith(".ttml") || path.endsWith(".dfxp") || mime.contains("ttml")) f = Format.TTML;
            else if (path.endsWith(".srt") || mime.contains("subrip") || mime.contains("srt")) f = Format.SRT;
            else if (path.endsWith(".m3u8")) f = Format.HLS;
            else f = Format.UNKNOWN;
            if (f == Format.UNKNOWN) return null;
            String safeLabel = label == null ? "" : label.trim();
            String lang = language == null ? "" : language.trim().replace('_', '-');
            if (lang.length() > 36 || !LANGUAGE.matcher(lang).matches()) lang = "";
            if (safeLabel.isEmpty()) safeLabel = lang.isEmpty() ? "Undertext" : lang;
            if (safeLabel.length() > 80) safeLabel = safeLabel.substring(0, 80);
            return new SubtitleTrack(uri.toASCIIString(), safeLabel, lang, pageUrl, f, manifest);
        } catch (Exception ignored) { return null; }
    }

    /** The Google default receiver understands separately served WebVTT and TTML. */
    public boolean externalCastReady() { return format == Format.WEBVTT || format == Format.TTML; }
    public String mimeType() { return format == Format.TTML ? "application/ttml+xml" : "text/vtt"; }
    public String key() { return url; }
    public String displayName() {
        return label + (language.isEmpty() || label.equalsIgnoreCase(language) ? "" : " (" + language + ")");
    }
}
