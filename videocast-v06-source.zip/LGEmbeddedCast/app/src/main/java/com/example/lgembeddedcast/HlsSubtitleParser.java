package com.example.lgembeddedcast;

import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** HLS multivariant playlist caption metadata. This is discovery only, not an HLS decoder. */
public final class HlsSubtitleParser {
    private HlsSubtitleParser() { }

    public static List<SubtitleTrack> parse(String manifestUrl, String manifest) {
        List<SubtitleTrack> result = new ArrayList<>();
        if (manifest == null || manifest.length() > 500_000 || !manifest.startsWith("#EXTM3U")) return result;
        try {
            URI base = new URI(manifestUrl);
            for (String line : manifest.split("\\r?\\n")) {
                if (!line.startsWith("#EXT-X-MEDIA:")) continue;
                Map<String,String> attrs = parseAttributes(line.substring("#EXT-X-MEDIA:".length()));
                if (!"SUBTITLES".equalsIgnoreCase(attrs.get("TYPE"))) continue;
                String ref = attrs.get("URI");
                if (ref == null || ref.isEmpty()) continue;
                SubtitleTrack track = SubtitleTrack.fromManifest(base.resolve(ref).toASCIIString(),
                        attrs.get("NAME"), attrs.get("LANGUAGE"), manifestUrl);
                if (track != null && result.size() < 30) result.add(track);
            }
        } catch (Exception ignored) { }
        return result;
    }

    static Map<String,String> parseAttributes(String text) {
        Map<String,String> fields = new LinkedHashMap<>();
        if (text == null) return fields;
        int i=0, n=text.length();
        while (i<n) {
            while (i<n && (text.charAt(i)==',' || Character.isWhitespace(text.charAt(i)))) i++;
            int start=i;
            while (i<n && text.charAt(i)!='=' && text.charAt(i)!=',') i++;
            if (i>=n || text.charAt(i)!='=') break;
            String key=text.substring(start,i++).trim();
            String value;
            if (i<n && text.charAt(i)=='"') {
                i++; StringBuilder buf=new StringBuilder();
                while (i<n) { char ch=text.charAt(i++); if (ch=='"') break; buf.append(ch); }
                value=buf.toString();
            } else {
                start=i; while (i<n && text.charAt(i)!=',') i++;
                value=text.substring(start,i).trim();
            }
            fields.put(key,value);
            if (i<n && text.charAt(i)==',') i++;
        }
        return fields;
    }
}
