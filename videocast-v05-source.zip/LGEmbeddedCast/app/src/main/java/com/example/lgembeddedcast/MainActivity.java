package com.example.lgembeddedcast;

import android.Manifest;
import androidx.fragment.app.FragmentActivity;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import java.util.Collections;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.os.SystemClock;
import android.content.SharedPreferences;
import android.widget.HorizontalScrollView;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;
import java.io.ByteArrayInputStream;
import java.net.URI;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.mediarouter.app.MediaRouteButton;

import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Browser + embedded video detector + LG webOS and Chromecast casting (no mirroring). */
public final class MainActivity extends FragmentActivity implements LgWebOsClient.Listener {
    private static final int BG = Color.rgb(13, 20, 32);
    private static final int PANEL = Color.rgb(24, 35, 50);
    private static final int PANEL_LIGHT = Color.rgb(35, 49, 68);
    private static final int ACCENT = Color.rgb(87, 204, 246);
    private static final int WHITE = Color.rgb(242, 247, 251);
    private static final int MUTED = Color.rgb(149, 168, 188);

    private FrameLayout root;
    private LinearLayout pageLayout;
    private WebView browser;
    private LinearLayout playerLayout, catalogLayout, catalogRows, categoryChips;
    private LinearLayout topBar, playerNavigation, playerSearchBar, playerFooter;
    private ScrollView mediaScroll;
    private View restoreChromeButton;
    private boolean chromeCollapsed = false;
    private boolean mediaExpanded = true;
    private int scrollDistance = 0;
    private float swipeStartY = 0;
    private long lastChromeChangeMs = 0;
    private EditText catalogSearch, siteSearch;
    private TextView catalogCount, currentSiteLabel;
    private final ArrayList<CatalogRepository.Entry> catalog = new ArrayList<>();
    private final Set<String> favorites = new LinkedHashSet<>();
    private String chosenCategory = "Alla";
    private String currentSiteHost = "";
    private boolean showingCatalog = true;
    private boolean blockAds = true;
    private long lastUserTap;
    private EditText address;
    private TextView status;
    private TextView mediaHeader;
    private LinearLayout mediaRows;
    private Button tvButton;
    private MediaRouteButton chromecastButton;
    private ChromecastController chromecast;
    private VideoCandidate waitingForChromecast;
    private enum CastTarget { NONE, LG, CHROMECAST }
    private CastTarget castTarget = CastTarget.NONE;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;
    private LgWebOsClient tvClient;
    private final LinkedHashMap<String, VideoCandidate> media = new LinkedHashMap<>();
    private final LinkedHashMap<String, TvDiscovery.Device> tvs = new LinkedHashMap<>();
    private String probeJavaScript;
    private volatile String lastPageTitle = "Inbäddad video";
    private VideoCandidate pendingSelection;
    private boolean scanning;
    private boolean documentStartProbeInstalled;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        tvClient = new LgWebOsClient(this, this);
        loadProbe();
        buildUI();
        setupBrowser();
        setupCatalog();
        try {
            chromecast = new ChromecastController(this, chromecastButton, new ChromecastController.Listener() {
                @Override public void onSessionReady() {
                    castTarget = CastTarget.CHROMECAST;
                    setStatus("Chromecast ansluten. Välj en video och tryck Casta.");
                    VideoCandidate queued = waitingForChromecast;
                    waitingForChromecast = null;
                    if (queued != null) sendToChromecast(queued);
                }
                @Override public void onSessionEnded() {
                    if (castTarget == CastTarget.CHROMECAST) castTarget = CastTarget.NONE;
                    waitingForChromecast = null;
                    setStatus("Chromecast frånkopplad.");
                }
                @Override public void onStatus(String message) { setStatus(message); }
            });
            if (chromecast.isConnected()) castTarget = CastTarget.CHROMECAST;
        } catch (RuntimeException | LinkageError error) {
            // Google Play services may be absent on some Android devices. LG casting still works.
            chromecastButton.setVisibility(View.GONE);
            setStatus("Google Cast är inte tillgängligt på den här telefonen. LG webOS fungerar fortfarande.");
        }
        handleShare(getIntent());
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES}, 20);
        } else {
            scanTvs();
        }
    }

    @Override public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShare(intent);
    }

    private void buildUI() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                root.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        }
        pageLayout = new LinearLayout(this);
        pageLayout.setOrientation(LinearLayout.VERTICAL);
        root.addView(pageLayout, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        LinearLayout head = row();
        topBar = head;
        head.setPadding(dp(10), dp(4), dp(10), dp(3));
        head.setBackgroundColor(BG);
        TextView logo = text("▣  VIDEO CAST", 14, ACCENT, true);
        logo.setOnClickListener(v -> showCatalog());
        head.addView(logo, new LinearLayout.LayoutParams(0, dp(34), 1));
        logo.setGravity(Gravity.CENTER_VERTICAL);
        tvButton = button("LG-TV", true);
        tvButton.setOnClickListener(v -> { castTarget = CastTarget.LG; showTvPicker(); });
        head.addView(tvButton, new LinearLayout.LayoutParams(-2, dp(34)));
        chromecastButton = new MediaRouteButton(this);
        chromecastButton.setContentDescription("Välj Chromecast eller Google Cast-TV");
        LinearLayout.LayoutParams castParams = new LinearLayout.LayoutParams(dp(40), dp(34));
        castParams.leftMargin = dp(5);
        head.addView(chromecastButton, castParams);
        pageLayout.addView(head);

        status = text("FMHY-katalog · välj en videowebbplats", 11, MUTED, false);
        status.setPadding(dp(10), 0, dp(10), dp(2));
        status.setSingleLine(true);
        status.setEllipsize(android.text.TextUtils.TruncateAt.END);
        status.setOnClickListener(v -> Toast.makeText(this, status.getText(), Toast.LENGTH_LONG).show());
        pageLayout.addView(status);
        createCatalogUi();
        playerLayout = new LinearLayout(this);
        playerLayout.setOrientation(LinearLayout.VERTICAL);
        playerLayout.setVisibility(View.GONE);
        pageLayout.addView(playerLayout, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = row();
        playerNavigation = nav;
        nav.setPadding(dp(6), dp(2), dp(6), dp(3));
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.addView(iconButton("⌂", v -> showCatalog()));
        nav.addView(iconButton("‹", v -> { if (browser.canGoBack()) browser.goBack(); }));
        nav.addView(iconButton("›", v -> { if (browser.canGoForward()) browser.goForward(); }));
        address = new EditText(this);
        address.setTextColor(WHITE);
        address.setHintTextColor(MUTED);
        address.setTextSize(13);
        address.setSingleLine(true);
        address.setPadding(dp(9), 0, dp(5), 0);
        address.setHint("Webbplatsens adress");
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setBackground(round(PANEL_LIGHT, 10));
        address.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);
        address.setOnEditorActionListener((v, action, event) -> { navigate(); return true; });
        nav.addView(address, new LinearLayout.LayoutParams(0, dp(34), 1));
        nav.addView(iconButton("→", v -> navigate()));
        nav.addView(iconButton("↻", v -> browser.reload()));
        nav.addView(iconButton("⤢", v -> setChromeCollapsed(true)));
        playerLayout.addView(nav);
        LinearLayout searchBar = row();
        playerSearchBar = searchBar;
        searchBar.setPadding(dp(6), 0, dp(6), dp(3));
        siteSearch = new EditText(this);
        siteSearch.setSingleLine(true); siteSearch.setTextSize(12);
        siteSearch.setTextColor(WHITE); siteSearch.setHintTextColor(MUTED);
        siteSearch.setHint("Sök film eller serie på denna webbplats");
        siteSearch.setInputType(InputType.TYPE_CLASS_TEXT);
        siteSearch.setBackground(round(PANEL_LIGHT, 9));
        siteSearch.setPadding(dp(9), 0, dp(6), 0);
        siteSearch.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        siteSearch.setOnEditorActionListener((v, action, event) -> { searchCurrentSite(); return true; });
        searchBar.addView(siteSearch, new LinearLayout.LayoutParams(0, dp(34), 1));
        Button searchButton = button("Sök", true);
        searchButton.setOnClickListener(v -> searchCurrentSite());
        searchBar.addView(searchButton, new LinearLayout.LayoutParams(-2, dp(34)));
        Button adToggle = button("🛡 På", false);
        adToggle.setOnClickListener(v -> {
            blockAds = !blockAds;
            adToggle.setText(blockAds ? "🛡 På" : "🛡 Av");
            setStatus(blockAds ? "Popups och kända annonsdomäner blockeras." : "Reklamskydd avstängt för denna session.");
            browser.reload();
        });
        searchBar.addView(adToggle, new LinearLayout.LayoutParams(-2, dp(34)));
        playerLayout.addView(searchBar);

        FrameLayout browserShell = new FrameLayout(this);
        browser = new WebView(this);
        browser.setBackgroundColor(Color.rgb(255, 255, 255));
        browserShell.addView(browser, new FrameLayout.LayoutParams(-1, -1));
        TextView restore = text("☰", 21, WHITE, true);
        restore.setGravity(Gravity.CENTER);
        restore.setBackground(round(PANEL_LIGHT, 12));
        restore.setElevation(dp(5));
        restore.setAlpha(0.92f);
        restore.setContentDescription("Visa webbläsarens kontroller");
        restore.setOnClickListener(v -> setChromeCollapsed(false));
        FrameLayout.LayoutParams restoreParams = new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.TOP | Gravity.END);
        restoreParams.setMargins(0, dp(5), dp(5), 0);
        browserShell.addView(restore, restoreParams);
        restoreChromeButton = restore;
        restore.setVisibility(View.GONE);
        playerLayout.addView(browserShell, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout footer = new LinearLayout(this);
        playerFooter = footer;
        footer.setOrientation(LinearLayout.VERTICAL);
        footer.setBackgroundColor(BG);
        footer.setPadding(dp(10), dp(5), dp(10), dp(4));
        // Keep only a compact single-row toolbar while browsing. A detected media list
        // unfolds beneath it; with no media detected, it consumes no height at all.
        LinearLayout summary = row();
        summary.setGravity(Gravity.CENTER_VERTICAL);
        mediaHeader = text("VIDEOR · 0", 11, WHITE, true);
        mediaHeader.setGravity(Gravity.CENTER_VERTICAL);
        mediaHeader.setOnClickListener(v -> {
            if (media.isEmpty()) {
                Toast.makeText(this, "Starta en video på webbsidan så söker appen efter en castbar ström.", Toast.LENGTH_LONG).show();
            } else {
                mediaExpanded = !mediaExpanded;
                refreshMediaRows();
            }
        });
        summary.addView(mediaHeader, new LinearLayout.LayoutParams(0, dp(32), 1));
        Button test = button("Test", false);
        test.setTextSize(11);
        test.setPadding(dp(6), 0, dp(6), 0);
        test.setOnClickListener(v -> openDemo());
        summary.addView(test, new LinearLayout.LayoutParams(-2, dp(29)));
        summary.addView(smallAction("▶", () -> remotePlayback("Play")));
        summary.addView(smallAction("Ⅱ", () -> remotePlayback("Pause")));
        summary.addView(smallAction("■", () -> remotePlayback("Stop")));
        footer.addView(summary);

        mediaScroll = new ScrollView(this);
        mediaScroll.setFillViewport(false);
        mediaScroll.setVisibility(View.GONE);
        mediaRows = new LinearLayout(this);
        mediaRows.setOrientation(LinearLayout.VERTICAL);
        mediaScroll.addView(mediaRows, new ScrollView.LayoutParams(-1, -2));
        footer.addView(mediaScroll, new LinearLayout.LayoutParams(-1, dp(75)));
        refreshMediaRows();
        playerLayout.addView(footer);
    }

    private void setupBrowser() {
        WebSettings s = browser.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSafeBrowsingEnabled(true);
        browser.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == android.view.MotionEvent.ACTION_DOWN) {
                lastUserTap = SystemClock.elapsedRealtime();
                swipeStartY = event.getY();
            } else if (event.getActionMasked() == android.view.MotionEvent.ACTION_UP && !showingCatalog) {
                // A fallback for sites whose video catalog scrolls in an inner HTML element
                // instead of scrolling the WebView's main document.
                float move = event.getY() - swipeStartY;
                if (SystemClock.elapsedRealtime() - lastChromeChangeMs > 550) {
                    if (move < -dp(75) && !chromeCollapsed) browser.post(() -> setChromeCollapsed(true));
                    if (move > dp(65) && chromeCollapsed) browser.post(() -> setChromeCollapsed(false));
                }
            }
            return false; // Never consume gestures needed by the website's own player.
        });
        // The webpage scroll drives the focus mode, not the toolbar's own layout.
        browser.setOnScrollChangeListener((view, x, y, oldX, oldY) -> onBrowserScrolled(y, oldY));
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(browser, true); // required by some embedded players
        browser.addJavascriptInterface(new BrowserBridge(), "AndroidMedia");
        // Install BEFORE loading the page, including third-party player frames.
        // The script observes media URLs only; it does not capture cookies or authentication headers.
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
                    && probeJavaScript != null && !probeJavaScript.isEmpty()) {
                WebViewCompat.addDocumentStartJavaScript(browser, probeJavaScript,
                        Collections.singleton("*"));
                documentStartProbeInstalled = true;
            }
        } catch (RuntimeException ignored) {
            documentStartProbeInstalled = false;
        }
        browser.setDownloadListener((url, agent, disposition, mime, length) -> {
            VideoCandidate video = VideoCandidate.from(url, mime, lastPageTitle, "Nedladdningslänk", false);
            if (video != null) addCandidate(video);
        });
        browser.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (!showingCatalog) setChromeCollapsed(false);
                media.clear();
                refreshMediaRows();
                if (url != null && url.startsWith("http")) address.setText(url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                lastPageTitle = view.getTitle() == null ? "Inbäddad video" : view.getTitle();
                injectProbe();
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (request != null && request.getUrl() != null) {
                    String resourceUrl = request.getUrl().toString();
                    if (blockAds && AdBlocker.blocks(resourceUrl))
                        return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                    VideoCandidate video = VideoCandidate.from(resourceUrl, "", lastPageTitle,
                            "Nätverksström", false);
                    if (video != null) runOnUiThread(() -> addCandidate(video));
                }
                return null;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (request == null || request.getUrl() == null) return true;
                String scheme = request.getUrl().getScheme();
                if (!("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme))) return true;
                String destination = request.getUrl().toString();
                if (blockAds && AdBlocker.blocks(destination)) return true;
                if (!request.isForMainFrame()) return false; // legitimate third-party media embeds
                String host = request.getUrl().getHost();
                if (host == null || currentSiteHost.isEmpty() || sameSite(host, currentSiteHost)) return false;
                boolean userInitiated = request.hasGesture() || SystemClock.elapsedRealtime() - lastUserTap < 1800;
                if (!userInitiated) {
                    setStatus("Oönskad automatisk omdirigering blockerad: " + host);
                    return true;
                }
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Öppna extern webbplats?")
                        .setMessage("Den här länken lämnar " + currentSiteHost + " och öppnar " + host
                                + ". Fortsätt bara om du känner igen webbplatsen.")
                        .setPositiveButton("Öppna", (dialog, which) -> {
                            currentSiteHost = host;
                            view.loadUrl(destination);
                        }).setNegativeButton("Blockera", null).show();
                return true;
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                    android.os.Message resultMsg) {
                setStatus("Reklam-popup eller nytt fönster blockerades.");
                return false;
            }
            @Override public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress == 100) injectProbe();
            }
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullscreenView != null) { callback.onCustomViewHidden(); return; }
                fullscreenView = view;
                fullscreenCallback = callback;
                pageLayout.setVisibility(View.GONE);
                root.addView(view, new FrameLayout.LayoutParams(-1, -1));
            }
            @Override public void onHideCustomView() { hideFullscreen(); }
            @Override public void onPermissionRequest(PermissionRequest request) {
                request.deny(); // video playback needs neither camera nor microphone permission
            }
        });
        showCatalog();
    }

    private final class BrowserBridge {
        @JavascriptInterface public void found(String json) {
            try {
                JSONObject obj = new JSONObject(json);
                VideoCandidate video = VideoCandidate.from(obj.optString("url"), obj.optString("mime"),
                        obj.optString("title"), obj.optString("source"), obj.optBoolean("iframe"));
                if (video != null) runOnUiThread(() -> addCandidate(video));
            } catch (Exception ignored) { }
        }
    }

    private void addCandidate(VideoCandidate candidate) {
        if (AdBlocker.blocks(candidate.url) || media.containsKey(candidate.key()) || media.size() >= 75) return;
        media.put(candidate.key(), candidate);
        refreshMediaRows();
    }

    private void refreshMediaRows() {
        if (mediaRows == null) return;
        mediaRows.removeAllViews();
        if (mediaHeader != null) mediaHeader.setText("VIDEOR · " + media.size()
                + (media.isEmpty() ? "" : (mediaExpanded ? " ▾" : " ▸")));
        if (mediaScroll != null) {
            mediaScroll.setVisibility(media.isEmpty() || !mediaExpanded ? View.GONE : View.VISIBLE);
        }
        if (media.isEmpty()) return;
        int count = 0;
        for (VideoCandidate video : media.values()) {
            if (++count > 40) break;
            LinearLayout item = row();
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(10), dp(7), dp(8), dp(7));
            item.setBackground(round(PANEL, 9));
            LinearLayout names = new LinearLayout(this);
            names.setOrientation(LinearLayout.VERTICAL);
            String title = video.title.length() > 55 ? video.title.substring(0, 55) + "…" : video.title;
            names.addView(text(title, 12, WHITE, true));
            names.addView(text(video.prettyKind() + "  •  " + video.source, 11, MUTED, false));
            item.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
            Button cast = button("Casta  ↗", true);
            cast.setOnClickListener(v -> castVideo(video));
            item.addView(cast, new LinearLayout.LayoutParams(-2, dp(37)));
            LinearLayout.LayoutParams margin = new LinearLayout.LayoutParams(-1, -2);
            margin.bottomMargin = dp(5);
            mediaRows.addView(item, margin);
        }
    }

    private void loadProbe() {
        try (InputStream in = getAssets().open("video_probe.js")) {
            java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
            byte[] chunk = new byte[4096];
            int length;
            while ((length = in.read(chunk)) != -1) bytes.write(chunk, 0, length);
            probeJavaScript = new String(bytes.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) { probeJavaScript = ""; }
    }
    private void injectProbe() {
        if (!documentStartProbeInstalled && browser != null && probeJavaScript != null
                && !probeJavaScript.isEmpty()) browser.evaluateJavascript(probeJavaScript, null);
        else if (browser != null) browser.evaluateJavascript(
                "window.__lgCastScan && window.__lgCastScan()", null);
    }

    private static boolean sameSite(String a, String b) {
        a = a.toLowerCase(Locale.ROOT).replaceFirst("^www\\.", "");
        b = b.toLowerCase(Locale.ROOT).replaceFirst("^www\\.", "");
        return a.equals(b) || a.endsWith("." + b) || b.endsWith("." + a);
    }
    private void createCatalogUi() {
        catalogLayout = new LinearLayout(this);
        catalogLayout.setOrientation(LinearLayout.VERTICAL);
        catalogLayout.setPadding(dp(12), dp(6), dp(12), dp(4));
        pageLayout.addView(catalogLayout, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView intro = text("Utforska videosidor", 24, WHITE, true);
        intro.setPadding(dp(2), dp(2), dp(2), dp(6));
        catalogLayout.addView(intro);
        TextView hint = text("Mobilanpassad FMHY-katalog. Välj en webbplats och sök filmer eller serier där.", 12, MUTED, false);
        hint.setPadding(dp(2), 0, dp(2), dp(10));
        catalogLayout.addView(hint);
        LinearLayout search = row();
        catalogSearch = new EditText(this);
        catalogSearch.setTextColor(WHITE); catalogSearch.setHintTextColor(MUTED);
        catalogSearch.setHint("Sök bland webbplatser och kategorier…");
        catalogSearch.setSingleLine(true); catalogSearch.setTextSize(15);
        catalogSearch.setBackground(round(PANEL_LIGHT, 12));
        catalogSearch.setPadding(dp(11), 0, dp(10), 0);
        catalogSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            public void onTextChanged(CharSequence s, int start, int before, int count) { refreshCatalogRows(); }
            public void afterTextChanged(Editable s) { }
        });
        search.addView(catalogSearch, new LinearLayout.LayoutParams(0, dp(46), 1));
        Button refresh = button("↻", false);
        refresh.setOnClickListener(v -> reloadCatalog());
        search.addView(refresh, new LinearLayout.LayoutParams(dp(47), dp(46)));
        catalogLayout.addView(search);

        HorizontalScrollView categories = new HorizontalScrollView(this);
        categories.setHorizontalScrollBarEnabled(false);
        categoryChips = row();
        categoryChips.setPadding(0, dp(11), 0, dp(10));
        categories.addView(categoryChips);
        catalogLayout.addView(categories);
        catalogCount = text("Laddar katalog…", 12, MUTED, false);
        catalogCount.setPadding(dp(3), 0, 0, dp(9));
        catalogLayout.addView(catalogCount);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        catalogRows = new LinearLayout(this);
        catalogRows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(catalogRows);
        catalogLayout.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        Button original = button("FMHY:s ursprungliga katalog ↗", false);
        original.setOnClickListener(v -> openSite(new CatalogRepository.Entry("FMHY Video", CatalogRepository.FMHY, "Katalog", "Originalkälla")));
        catalogLayout.addView(original, new LinearLayout.LayoutParams(-1, dp(42)));
    }
    private void setupCatalog() {
        favorites.addAll(getSharedPreferences("favorites", MODE_PRIVATE).getStringSet("urls", java.util.Collections.emptySet()));
        catalog.clear(); catalog.addAll(CatalogRepository.cached(this));
        refreshCategories(); refreshCatalogRows();
        reloadCatalog();
    }
    private void reloadCatalog() {
        setStatus("Uppdaterar FMHY-länkar, lokal katalog fungerar även offline…");
        CatalogRepository.refresh(this, (entries, message) -> {
            if (isFinishing() || isDestroyed()) return;
            catalog.clear(); catalog.addAll(entries);
            refreshCategories(); refreshCatalogRows();
            if (showingCatalog) setStatus(message);
        });
    }
    private void refreshCategories() {
        categoryChips.removeAllViews();
        LinkedHashSet<String> categories = new LinkedHashSet<>();
        categories.add("Alla"); categories.add("Favoriter");
        for (CatalogRepository.Entry entry : catalog) categories.add(entry.category);
        if (!categories.contains(chosenCategory)) chosenCategory = "Alla";
        for (String category : categories) {
            Button chip = button(category, category.equals(chosenCategory));
            chip.setTextSize(11);
            chip.setOnClickListener(v -> {
                chosenCategory = category;
                refreshCategories(); refreshCatalogRows();
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(36));
            params.rightMargin = dp(6);
            categoryChips.addView(chip, params);
        }
    }
    private void refreshCatalogRows() {
        if (catalogRows == null) return;
        catalogRows.removeAllViews();
        String query = catalogSearch == null ? "" : catalogSearch.getText().toString().toLowerCase(Locale.ROOT).trim();
        int shown = 0;
        for (CatalogRepository.Entry entry : catalog) {
            if (!chosenCategory.equals("Alla") && !chosenCategory.equals("Favoriter") && !chosenCategory.equals(entry.category)) continue;
            if (chosenCategory.equals("Favoriter") && !favorites.contains(entry.url)) continue;
            if (!query.isEmpty() && !(entry.title + " " + entry.category + " " + entry.description).toLowerCase(Locale.ROOT).contains(query)) continue;
            if (++shown > 300) break;  // Keep scrolling responsive on low-memory devices.
            LinearLayout item = row(); item.setGravity(Gravity.CENTER_VERTICAL);
            item.setBackground(round(PANEL, 12));
            item.setPadding(dp(12), dp(8), dp(7), dp(8));
            LinearLayout labels = new LinearLayout(this); labels.setOrientation(LinearLayout.VERTICAL);
            TextView name = text(entry.title, 15, WHITE, true);
            labels.addView(name);
            TextView details = text(entry.category, 11, MUTED, false);
            labels.addView(details);
            labels.setOnClickListener(v -> openSite(entry));
            item.addView(labels, new LinearLayout.LayoutParams(0, dp(52), 1));
            TextView star = text(favorites.contains(entry.url) ? "★" : "☆", 25, favorites.contains(entry.url) ? ACCENT : MUTED, false);
            star.setGravity(Gravity.CENTER);
            star.setOnClickListener(v -> {
                if (favorites.contains(entry.url)) favorites.remove(entry.url); else favorites.add(entry.url);
                getSharedPreferences("favorites", MODE_PRIVATE).edit().putStringSet("urls", new LinkedHashSet<>(favorites)).apply();
                refreshCatalogRows();
            });
            item.addView(star, new LinearLayout.LayoutParams(dp(42), dp(48)));
            TextView open = text("›", 29, ACCENT, false);
            open.setGravity(Gravity.CENTER);
            open.setOnClickListener(v -> openSite(entry));
            item.addView(open, new LinearLayout.LayoutParams(dp(31), dp(48)));
            LinearLayout.LayoutParams space = new LinearLayout.LayoutParams(-1, -2);
            space.bottomMargin = dp(7);
            catalogRows.addView(item, space);
        }
        catalogCount.setText("" + Math.min(shown, 300) + " webbplatser · tryck ☆ för favoriter");
        if (shown == 0) catalogRows.addView(text("Inga träffar. Sök efter en webbplats, inte en filmtitel. Filmtitlar söker du på den valda webbplatsen.", 13, MUTED, false));
    }
    private void openSite(CatalogRepository.Entry site) {
        showingCatalog = false;
        setChromeCollapsed(false);
        catalogLayout.setVisibility(View.GONE);
        playerLayout.setVisibility(View.VISIBLE);
        currentSiteHost = android.net.Uri.parse(site.url).getHost();
        if (currentSiteHost == null) currentSiteHost = "";
        lastPageTitle = site.title;
        address.setText(site.url);
        siteSearch.setText("");
        media.clear(); refreshMediaRows();
        setStatus("Öppnar " + site.title + " · popupskydd på. Spela videon, välj sedan ström att casta.");
        browser.loadUrl(site.url);
    }
    private void showCatalog() {
        if (!showingCatalog) setChromeCollapsed(false);
        showingCatalog = true;
        if (browser != null) { browser.stopLoading(); browser.loadUrl("about:blank"); }
        currentSiteHost = "";
        if (playerLayout != null) playerLayout.setVisibility(View.GONE);
        if (catalogLayout != null) catalogLayout.setVisibility(View.VISIBLE);
        setStatus("Välj källa. Sökning i katalogen hittar webbplatser; filmtitlar söker du på webbplatsen.");
    }
    private void searchCurrentSite() {
        String q = siteSearch.getText().toString().trim();
        if (q.isEmpty()) { Toast.makeText(this, "Ange en filmtitel eller serie", Toast.LENGTH_SHORT).show(); return; }
        String argument = JSONObject.quote(q);
        String js = "(function(){var q=" + argument + ";var f=document.querySelector('input[type=search],input[name=q],input[name=query],input[name=search],input[placeholder*=Search],input[placeholder*=search],input[placeholder*=Sök]');"
                + "if(!f)return 'missing';f.focus();var p=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');p.set.call(f,q);"
                + "f.dispatchEvent(new Event('input',{bubbles:true}));f.dispatchEvent(new Event('change',{bubbles:true}));"
                + "var form=f.form;if(form){form.requestSubmit?form.requestSubmit():form.submit();}"
                + "else{f.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',bubbles:true}));f.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',bubbles:true}));}return 'ok'})()";
        browser.evaluateJavascript(js, result -> {
            if ("\"missing\"".equals(result)) setStatus("Ingen sökruta hittades. Använd webbplatsens egen sökfunktion i spelvyn.");
            else setStatus("Söker på webbplatsen efter: " + q);
        });
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(siteSearch.getWindowToken(), 0);
    }

    private void showWelcome() {
        String html = "<!DOCTYPE html><html lang='sv'><meta name='viewport' content='width=device-width, initial-scale=1'>" +
                "<style>body{background:#101925;color:#f2f8ff;font:16px sans-serif;margin:0;padding:26px;}" +
                "h1{font-size:27px;} .step{background:#203145;padding:17px;border-radius:14px;margin:14px 0;}" +
                "small{color:#a7bbcd;} b{color:#66cffa;}</style>" +
                "<h1>Casta bara videon, inte skärmen.</h1>" +
                "<div class='step'><b>1.</b> Öppna en webbsida med inbäddad video.</div>" +
                "<div class='step'><b>2.</b> Välj <b>LG-TV</b> eller tryck på Cast-symbolen för <b>Chromecast</b>.</div>" +
                "<div class='step'><b>3.</b> Starta videon på sidan och tryck sedan på <b>Casta</b>.</div>" +
                "<small>Det är bara videon som skickas – ingen skärmspegling. " +
                "Direktströmmar fungerar bäst; DRM och videor som kräver inloggningscookies kan vara begränsade.</small></html>";
        browser.loadDataWithBaseURL("https://example.org", html, "text/html", "UTF-8", null);
    }

    private void openDemo() {
        String html = "<!DOCTYPE html><html lang='sv'><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<style>body{background:#0c1422;color:white;font:16px sans-serif;margin:22px}video{width:100%;border-radius:12px}</style>" +
                "<h2>Test: fri MP4-video</h2><p>Tryck på uppspelning. Videon ska dyka upp i listan under webbläsaren.</p>" +
                "<video controls playsinline src='https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4'></video>" +
                "<p>Källa: MDN, CC0-exempel.</p></html>";
        browser.loadDataWithBaseURL("https://example.org", html, "text/html", "UTF-8", null);
    }

    private void navigate() {
        String input = address.getText().toString().trim();
        if (input.isEmpty()) return;
        if (!input.matches("(?i)^https?://.*")) input = "https://" + input;
        try {
            java.net.URI uri = new java.net.URI(input);
            if (uri.getHost() == null) throw new IllegalArgumentException();
            currentSiteHost = uri.getHost();
            browser.loadUrl(uri.toASCIIString());
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(address.getWindowToken(), 0);
            address.clearFocus();
        } catch (Exception e) { Toast.makeText(this, "Ogiltig webbadress", Toast.LENGTH_SHORT).show(); }
    }

    private void handleShare(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (shared == null) return;
        Matcher matcher = Pattern.compile("https?://[^\\s<>'\"]+").matcher(shared);
        if (matcher.find()) {
            String url = matcher.group().replaceAll("[.,;]+$", "");
            if (browser != null) openSite(new CatalogRepository.Entry("Delad länk", url, "Delad länk", ""));
        }
    }

    private void scanTvs() {
        if (scanning) return;
        scanning = true;
        setStatus("Söker efter LG-TV. Chromecast hittas via Cast-knappen …");
        TvDiscovery.scan(this, new TvDiscovery.Listener() {
            @Override public void onTv(TvDiscovery.Device tv) {
                TvDiscovery.Device old = tvs.get(tv.ip);
                if (old == null || tv.avTransportUrl != null || !tv.name.startsWith("LG webOS")) tvs.put(tv.ip, tv);
                setStatus(tvs.size() + " LG-TV hittades. Tryck på Välj TV.");
            }
            @Override public void onDone(String error) {
                scanning = false;
                if (error != null) setStatus(error);
                else if (tvs.isEmpty()) setStatus("Ingen TV hittades. Ange TV:ns IP-adress via Välj TV.");
                else setStatus("Hittade " + tvs.size() + " LG-TV. Välj en för parkoppling.");
            }
        });
    }

    private void showTvPicker() {
        boolean haveCurrent = tvClient.device() != null;
        String[] options = new String[tvs.size() + (haveCurrent ? 3 : 2)];
        int i = 0;
        for (TvDiscovery.Device d : tvs.values()) options[i++] = "▣  " + d.name + " (" + d.ip + ")";
        options[i++] = "↻  Sök efter LG-TV igen";
        options[i++] = "+  Ange IP-adress manuellt";
        if (haveCurrent) options[i] = "×  Glöm parkoppling till aktuell TV";
        new AlertDialog.Builder(this).setTitle("Välj LG webOS-TV")
                .setItems(options, (dialog, which) -> {
                    if (which < tvs.size()) {
                        TvDiscovery.Device tv = tvs.values().toArray(new TvDiscovery.Device[0])[which];
                        castTarget = CastTarget.LG;
                        tvButton.setText("LG: " + tv.ip);
                        tvClient.connect(tv);
                    } else if (which == tvs.size()) {
                        tvs.clear();
                        scanTvs();
                    } else if (which == tvs.size() + 1) {
                        showManualIpDialog();
                    } else if (tvClient.device() != null) {
                        String ip = tvClient.device().ip;
                        tvClient.forgetPairing(ip);
                        tvClient.disconnect();
                        tvButton.setText("Välj TV");
                        setStatus("Parkopplingen är glömd. Anslut igen för att parkoppla på nytt.");
                    }
                }).setNegativeButton("Avbryt", null).show();
    }

    /** One video list serves both devices; the last explicitly selected target wins. */
    private void castVideo(VideoCandidate video) {
        if (castTarget == CastTarget.CHROMECAST && chromecast != null && chromecast.isConnected()) {
            sendToChromecast(video);
        } else if (castTarget == CastTarget.LG && tvClient.device() != null) {
            sendToLg(video);
        } else if (chromecast != null && chromecast.isConnected() && tvClient.device() == null) {
            castTarget = CastTarget.CHROMECAST;
            sendToChromecast(video);
        } else if (tvClient.device() != null && (chromecast == null || !chromecast.isConnected())) {
            castTarget = CastTarget.LG;
            sendToLg(video);
        } else {
            chooseTarget(video);
        }
    }

    private void chooseTarget(VideoCandidate video) {
        String[] choices = chromecast == null
                ? new String[] { "LG webOS-TV" }
                : new String[] { "Chromecast / Google Cast-TV", "LG webOS-TV" };
        new AlertDialog.Builder(this).setTitle("Casta video till")
                .setItems(choices, (dialog, selected) -> {
                    if (chromecast != null && selected == 0) {
                        castTarget = CastTarget.CHROMECAST;
                        if (video.kind == VideoCandidate.Kind.YOUTUBE) {
                            Toast.makeText(this, "YouTube-inbäddningar kräver YouTubes egen Cast-knapp.", Toast.LENGTH_LONG).show();
                            return;
                        }
                        waitingForChromecast = video;
                        // A cancelled picker must not cause this video to start on a later session.
                        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                            if (waitingForChromecast == video) waitingForChromecast = null;
                        }, 60_000);
                        if (chromecast.isConnected()) {
                            waitingForChromecast = null;
                            sendToChromecast(video);
                        } else if (!chromecastButton.performClick()) {
                            waitingForChromecast = null;
                            setStatus("Tryck på Cast-symbolen längst upp och välj din Chromecast.");
                        }
                    } else {
                        castTarget = CastTarget.LG;
                        if (tvClient.device() == null) {
                            pendingSelection = video;
                            showTvPicker();
                        } else sendToLg(video);
                    }
                }).setNegativeButton("Avbryt", null).show();
    }

    private void sendToLg(VideoCandidate video) {
        // The receiver has to fetch the URL independently. First check whether it is
        // anonymously accessible; do not forward browsing session credentials to the TV.
        MediaUrlCheck.check(video, result -> {
            if (result.invalid) setStatus("Inte en spelbar direktström: " + result.message);
            else if (!result.blocked) tvClient.cast(video);
            else showReachabilityWarning(result.message, () -> tvClient.cast(video));
        });
    }

    private void sendToChromecast(VideoCandidate video) {
        if (chromecast == null) return;
        if (video.kind == VideoCandidate.Kind.MKV) {
            setStatus("Chromecast standardmottagare stöder inte MKV. Använd LG-TV eller MP4/HLS/DASH.");
            return;
        }
        MediaUrlCheck.check(video, result -> {
            if (result.invalid) setStatus("Inte en spelbar direktström: " + result.message);
            else if (!result.blocked) chromecast.cast(video);
            else showReachabilityWarning(result.message, () -> chromecast.cast(video));
        });
    }

    private void showReachabilityWarning(String message, Runnable sendAnyway) {
        if (isFinishing() || isDestroyed()) return;
        new AlertDialog.Builder(this).setTitle("TV:n kan sakna åtkomst")
                .setMessage(message + "\n\nFörsök ändå, eller byt källa/spelare på webbsidan.")
                .setPositiveButton("Försök ändå", (dialog, which) -> sendAnyway.run())
                .setNegativeButton("Avbryt", null).show();
    }

    private void pauseBrowserVideo() {
        if (browser != null) browser.evaluateJavascript(
                "(function(){document.querySelectorAll('video').forEach(v=>v.pause());})()", null);
    }

    private void remotePlayback(String action) {
        if (castTarget == CastTarget.CHROMECAST && chromecast != null && chromecast.isConnected()) {
            chromecast.playback(action);
        } else if (castTarget == CastTarget.LG && tvClient.device() != null) {
            tvClient.playback(action);
        } else if (chromecast != null && chromecast.isConnected()) {
            castTarget = CastTarget.CHROMECAST;
            chromecast.playback(action);
        } else if (tvClient.device() != null) {
            castTarget = CastTarget.LG;
            tvClient.playback(action);
        } else {
            setStatus("Välj en LG-TV eller Chromecast först.");
        }
    }

    private void showManualIpDialog() {
        EditText ip = new EditText(this);
        ip.setSingleLine();
        ip.setInputType(InputType.TYPE_CLASS_PHONE);
        ip.setHint("192.168.1.50");
        ip.setPadding(dp(20), dp(15), dp(20), dp(15));
        new AlertDialog.Builder(this).setTitle("TV:ns lokala IP-adress")
                .setView(ip).setNegativeButton("Avbryt", null)
                .setPositiveButton("Anslut", (dialog, which) -> {
                    String host = ip.getText().toString().trim();
                    if (!TvDiscovery.isLocalAddress(host)) {
                        Toast.makeText(this, "Ange en privat IPv4-adress på ditt Wi-Fi", Toast.LENGTH_LONG).show();
                        return;
                    }
                    TvDiscovery.Device tv = new TvDiscovery.Device(host, "LG-TV " + host, null);
                    tvs.put(host, tv);
                    castTarget = CastTarget.LG;
                    tvButton.setText("LG: " + host);
                    tvClient.connect(tv);
                }).show();
    }

    /** Automatically reduce chrome on downward webpage scrolling and restore it on upward scrolling. */
    private void onBrowserScrolled(int scrollY, int oldScrollY) {
        if (showingCatalog || fullscreenView != null) return;
        int delta = scrollY - oldScrollY;
        if (Math.abs(delta) < dp(2)) return;
        if (SystemClock.elapsedRealtime() - lastChromeChangeMs < 450) return;
        if (delta > 0 && !chromeCollapsed && scrollY > dp(65)) {
            scrollDistance = Math.max(0, scrollDistance) + delta;
            if (scrollDistance > dp(35)) setChromeCollapsed(true);
        } else if (delta < 0 && chromeCollapsed) {
            scrollDistance = Math.min(0, scrollDistance) + delta;
            if (scrollDistance < -dp(24) || scrollY <= dp(4)) setChromeCollapsed(false);
        } else {
            scrollDistance = 0;
        }
    }

    private void setChromeCollapsed(boolean collapsed) {
        if (showingCatalog || chromeCollapsed == collapsed) return;
        chromeCollapsed = collapsed;
        scrollDistance = 0;
        lastChromeChangeMs = SystemClock.elapsedRealtime();
        topBar.setVisibility(collapsed ? View.GONE : View.VISIBLE);
        status.setVisibility(collapsed ? View.GONE : View.VISIBLE);
        playerNavigation.setVisibility(collapsed ? View.GONE : View.VISIBLE);
        playerSearchBar.setVisibility(collapsed ? View.GONE : View.VISIBLE);
        playerFooter.setVisibility(collapsed ? View.GONE : View.VISIBLE);
        restoreChromeButton.setVisibility(collapsed ? View.VISIBLE : View.GONE);
    }

    private void setStatus(String s) { runOnUiThread(() -> { if (status != null) status.setText(s); }); }
    @Override public void onStatus(String s) { setStatus(s); }
    @Override public void onConnected(TvDiscovery.Device tv) {
        runOnUiThread(() -> {
            castTarget = CastTarget.LG;
            tvButton.setText("✓ LG");
            if (pendingSelection != null) {
                VideoCandidate candidate = pendingSelection;
                pendingSelection = null;
                tvClient.cast(candidate);
                browser.evaluateJavascript("(function(){document.querySelectorAll('video').forEach(v=>v.pause());})()", null);
            }
        });
    }
    @Override public void onCastResult(boolean ok, String message) {
        runOnUiThread(() -> {
            setStatus(message);
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        });
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == 20) scanTvs();
    }

    private void hideFullscreen() {
        if (fullscreenView == null) return;
        root.removeView(fullscreenView);
        fullscreenView = null;
        pageLayout.setVisibility(View.VISIBLE);
        if (fullscreenCallback != null) fullscreenCallback.onCustomViewHidden();
        fullscreenCallback = null;
    }
    @Override public void onBackPressed() {
        if (fullscreenView != null) hideFullscreen();
        else if (!showingCatalog && browser.canGoBack()) browser.goBack();
        else if (!showingCatalog) showCatalog();
        else super.onBackPressed();
    }
    @Override public void onDestroy() {
        if (chromecast != null) chromecast.close();
        tvClient.disconnect();
        if (browser != null) { browser.stopLoading(); browser.destroy(); }
        super.onDestroy();
    }

    private int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + .5f); }
    private LinearLayout row() { LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); return r; }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextColor(color); v.setTextSize(sp);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        return d;
    }
    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(12);
        b.setTextColor(primary ? BG : WHITE);
        b.setBackground(round(primary ? ACCENT : PANEL_LIGHT, 10));
        b.setPadding(dp(13), 0, dp(13), 0);
        b.setMinWidth(0); b.setMinimumWidth(0);
        b.setMinHeight(0); b.setMinimumHeight(0);
        return b;
    }
    private View iconButton(String icon, View.OnClickListener callback) {
        TextView v = text(icon, 25, WHITE, false);
        v.setGravity(Gravity.CENTER);
        v.setOnClickListener(callback);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(34)));
        return v;
    }
    private View smallAction(String label, Runnable run) {
        Button b = button(label, false);
        b.setTextSize(16);
        b.setOnClickListener(v -> run.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(35), dp(30));
        params.leftMargin = dp(3);
        b.setLayoutParams(params);
        return b;
    }
}
