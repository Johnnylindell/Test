# Video Cast 0.4 — mobil FMHY-katalog + LG & Chromecast

## Funktioner

- Startar i en **inbyggd mobil katalogvy**, som läser metadata och länkar från https://fmhy.net/video. Det här är inte en oförändrad webbsida eller en filmdatabas.
- Lokalt cachelagrade webbplatsnamn, kategorier, filtrering och favoriter; kan uppdateras från FMHY med ett tryck. En liten verifierad startlista finns i appen för offlineanvändning.
- Öppna en vald webbplats i en **separat spelvy** och navigera där. Sök i webbplatsens egna sökfält via appens sökruta när webbplatsen har ett sådant.
- Blockerar nya popupfönster, kända reklamdomäner och misstänkta automatiska omdirigeringar mellan webbplatser. **Inte en fullständig uBlock Origin-ersättare**. Reklamskydd kan stängas av.
- Identifierar vissa direktströmmar (MP4, HLS, DASH, WebM, MKV och MPEG-TS) i videospelare och nätverksanrop. Kontrollerar direktlänkar före sändning för att undvika HTML-sidor som TV-filer.
- LG webOS (direkt via nätverk) och Chromecast (Google Cast SDK). Ingen skärmspegling.
- En öppen webbsida är **inte automatiskt** en castbar video. DRM, specialcookies, kodningar och referrer-/token-krav kan hindra uppspelning på TV.

## Bygga

Android Studio: öppna denna katalog. Android SDK 37, Java 17, Gradle 9.3.1, Android Gradle Plugin 9.1.1.
Kör `gradle :app:testDebugUnitTest :app:assembleDebug`. Debug-APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Test

Kontrollera på telefonen katalog, sökning, popupskydd, videoupptäckt och uppspelning mot din faktiska TV. CI kompilering/tidsbegränsade enhetstester är inte samma sak som test på LG/Chromecast.

## Viktigt

FMHY-listan och externa streamingtjänster tillhör sina respektive utgivare. Appen hostar eller lagrar inga filmer, sparar inga inloggningsuppgifter och kringgår inte DRM eller betalväggar. Använd lagliga källor.


## v0.5 — Compact adaptive browser layout

- Keeps the FMHY mobile catalog, LG webOS and Google Cast integrations.
- Compact single-row bottom toolbar with Test, Play, Pause and Stop.
- Media list uses no space until a playable video candidate is found; tap `VIDEOR` to expand/collapse.
- Scroll down on the webpage to hide all app bars, scroll up to restore.
- A floating ☰ control always restores the bars. Use ⤢ in the navigation toolbar to enter focus mode manually.
- Supports sites with nested scrolling containers via a swipe-gesture fallback.
- This is a debug build for testing; video stream compatibility still depends on the TV, provider and media format.
