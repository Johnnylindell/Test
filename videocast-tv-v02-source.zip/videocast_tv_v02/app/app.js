(function(){'use strict';
var $=function(id){return document.getElementById(id);};
var Logic=window.VideoCastLogic;
var TitleSearch=window.VideoCastTitleSearch;
var catalog=(window.VIDEOCAST_CATALOG||[]).slice();
var favs=readStore('videocast:favorites',[]), recent=readStore('videocast:recent',[]), extra=readStore('videocast:custom',[]);
var activeFilter='all', mode='home', currentSite=null, beforePlayer='home', modalOpen=false;
var discoveryFilter='all', discoveryResults=[], discoveryQuery='', chosenTitle=null, showAllSources=false, discoveryRequest=0, siteReturnMode='home';
var video=$('video'), toastTimer=null, currentFrameTimeout=null;
var title=$('catalogTitle'), grid=$('catalogGrid'), query=$('catalogQuery');
catalog=catalog.concat(extra);
function readStore(k,fallback){try{var v=JSON.parse(localStorage.getItem(k));return Array.isArray(v)?v:fallback;}catch(e){return fallback;}}
function writeStore(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
function text(el,value){el.textContent=String(value||'');}
function message(m){var el=$('toast');text(el,m);el.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(function(){el.classList.remove('visible');},4500);}
function setMode(m){mode=m;$('homeView').classList.toggle('hidden',m!=='home');$('sidebar').classList.toggle('hidden',m!=='home');$('siteView').classList.toggle('hidden',m!=='site');$('playerView').classList.toggle('hidden',m!=='player');$('discoveryView').classList.toggle('hidden',m!=='discover');}
function categories(){var c=[];catalog.forEach(function(s){if(c.indexOf(s.category)<0)c.push(s.category);});c.sort();return c;}
function categoryName(f){return f==='all'?'Alla webbplatser':f==='favorites'?'Favoriter':f==='recent'?'Senast besökta':f;}
function redrawCategories(){var nav=$('categoryNavigation');nav.textContent='';categories().forEach(function(cat){var b=document.createElement('button');b.className='nav';b.type='button';b.dataset.filter=cat;text(b,cat);nav.appendChild(b);});highlightNavigation();}
function highlightNavigation(){document.querySelectorAll('[data-filter]').forEach(function(btn){btn.classList.toggle('active',btn.dataset.filter===activeFilter);});}
function redrawCatalog(){
  var entries=Logic.searchEntries(catalog,query.value,activeFilter,favs,recent);
  text(title,categoryName(activeFilter));text($('catalogCount'),entries.length+' webbplatser');grid.textContent='';
  entries.forEach(function(site){
    var b=document.createElement('div');b.className='card';b.tabIndex=0;b.setAttribute('role','button');b.setAttribute('aria-label','Öppna '+site.title);
    var h=document.createElement('div');h.className='card-name';text(h,site.title);
    var cat=document.createElement('div');cat.className='card-category';text(cat,site.category);
    var host=document.createElement('div');host.className='card-url';try{text(host,new URL(site.url).hostname);}catch(e){text(host,site.url);}
    var star=document.createElement('button');star.type='button';star.className='favorite'+(favs.indexOf(site.url)>=0?' checked':'');text(star,favs.indexOf(site.url)>=0?'★':'☆');star.setAttribute('aria-label','Favorit '+site.title);
    star.addEventListener('click',function(e){e.stopPropagation();if(favs.indexOf(site.url)>=0)favs=favs.filter(function(x){return x!==site.url;});else favs.push(site.url);writeStore('videocast:favorites',favs);redrawCatalog();});
    b.appendChild(h);b.appendChild(cat);b.appendChild(host);b.appendChild(star);
    b.addEventListener('click',function(){openSite(site);});b.addEventListener('keydown',function(e){if(e.key==='Enter'){e.stopPropagation();openSite(site);}});
    grid.appendChild(b);
  });
  $('emptyState').classList.toggle('hidden',entries.length>0);
}
function openSite(site){siteReturnMode=mode==='discover'?'discover':'home';currentSite=site;recent=recent.filter(function(x){return x!==site.url;});recent.unshift(site.url);recent=recent.slice(0,30);writeStore('videocast:recent',recent);text($('siteName'),site.title);text($('siteAddress'),site.url);setMode('site');var f=$('siteFrame');f.src='about:blank';f.src=site.url;clearTimeout(currentFrameTimeout);currentFrameTimeout=setTimeout(function(){if(mode==='site')message('Om webbplatsen är tom: välj "Öppna i LG-webbläsaren".');},5000);$('siteBrowser').focus();}
function launchBrowser(){var url=currentSite&&currentSite.url;if(!url)return;var failed=function(){message('Kunde inte öppna TV-webbläsaren. Kontrollera att din webOS-modell stöder detta.');};
  if(window.webOSDev&&window.webOSDev.launch&&window.webOSDev.APP&&window.webOSDev.APP.BROWSER){window.webOSDev.launch({id:window.webOSDev.APP.BROWSER,params:{target:url},onFailure:failed});return;}
  if(window.webOS&&window.webOS.service){window.webOS.service.request('luna://com.webos.applicationManager',{method:'launch',parameters:{id:'com.webos.app.browser',params:{target:url}},onFailure:failed});return;}
  var w=window.open(url,'_blank');if(!w)failed();
}
function goHome(){if(mode==='site'){$('siteFrame').src='about:blank';}if(mode==='site'&&siteReturnMode==='discover'){setMode('discover');$('titleQuery').focus();return;}setMode('home');redrawCatalog();$('catalogQuery').focus();}
function showPlayer(){beforePlayer=mode;setMode('player');$('videoUrl').focus();}
function leavePlayer(){video.pause();setMode(beforePlayer==='site'?'site':beforePlayer==='discover'?'discover':'home');if(mode==='site')$('siteBrowser').focus();else if(mode==='discover')$('titleQuery').focus();else $('catalogQuery').focus();}
function loadVideo(){var u=Logic.normalizeUrl($('videoUrl').value);if(!u){message('Ange en giltig http(s)-adress till en videoström.');return;}video.pause();video.removeAttribute('src');video.querySelectorAll('track').forEach(function(t){t.remove();});video.load();$('playerOverlay').classList.add('hidden');video.src=u;video.load();var p=video.play();if(p&&p.catch)p.catch(function(){message('Uppspelning kunde inte startas. Tryck Play eller välj annan ström.');});}
function togglePlayback(){if(video.paused){var p=video.play();if(p&&p.catch)p.catch(function(){message('Uppspelning stöds inte av TV:n.');});}else video.pause();}
function seek(delta){if(isFinite(video.duration)&&video.duration>0)video.currentTime=Math.min(video.duration,Math.max(0,video.currentTime+delta));}
function updatePosition(){text($('positionText'),Logic.formatTime(video.currentTime));text($('durationText'),Logic.formatTime(video.duration));if(isFinite(video.duration)&&video.duration>0)$('seekBar').value=Math.round(video.currentTime/video.duration*1000);}
function refreshSubtitles(){var area=$('subtitleOptions');area.textContent='';var off=document.createElement('button');off.type='button';off.className='button dim';text(off,'Av');off.onclick=function(){for(var i=0;i<video.textTracks.length;i++)video.textTracks[i].mode='disabled';closeSubs();};area.appendChild(off);for(var i=0;i<video.textTracks.length;i++){(function(index){var track=video.textTracks[index];var btn=document.createElement('button');btn.type='button';btn.className='button dim';text(btn,track.label||track.language||'Spår '+(index+1));btn.onclick=function(){for(var j=0;j<video.textTracks.length;j++)video.textTracks[j].mode=j===index?'showing':'disabled';closeSubs();};area.appendChild(btn);})(i);}if(video.textTracks.length===0){var tip=document.createElement('span');text(tip,'Inga undertexter hittades i strömmen. Lägg till extern WebVTT om det finns.');area.appendChild(tip);}}
function closeSubs(){$('subtitleModal').classList.add('hidden');modalOpen=false;$('subtitleButton').focus();}
function addSubtitle(){var u=Logic.normalizeUrl($('subtitleUrl').value);if(!u||!(/\.vtt([?#]|$)/i.test(u))){message('Ange en WebVTT-länk som slutar med .vtt.');return;}var t=document.createElement('track');t.kind='subtitles';t.label='Extern';t.srclang='sv';t.src=u;video.appendChild(t);refreshSubtitles();message('Undertext tillagd. Om den inte visas kan servern neka åtkomst (CORS).');}
function addSite(){var title=prompt('Webbplatsens namn?');if(!title)return;var url=Logic.normalizeUrl(prompt('Webbadress (https://...)')||'');if(!url){message('Ogiltig webbadress.');return;}if(catalog.some(function(x){return x.url===url;})){message('Webbplatsen finns redan.');return;}var site={title:title.slice(0,70),url:url,category:'Egna länkar',description:'Tillagd på TV:n'};extra.push(site);catalog.push(site);writeStore('videocast:custom',extra);redrawCategories();activeFilter='all';query.value='';highlightNavigation();redrawCatalog();message('Webbplats tillagd.');}
function goBack(){if(modalOpen){closeSubs();return;}if(mode==='player'){leavePlayer();return;}if(mode==='site'){goHome();return;}if(mode==='discover'){setMode('home');redrawCatalog();$('catalogQuery').focus();return;}if(activeFilter!=='all'||query.value){activeFilter='all';query.value='';highlightNavigation();redrawCatalog();$('catalogQuery').focus();return;}if(window.webOS&&window.webOS.platformBack)window.webOS.platformBack();else message('Tryck Home på fjärrkontrollen för att lämna appen.');}
function spatialKey(e){var list=Array.prototype.slice.call(document.querySelectorAll('button,input,.card[tabindex]')).filter(function(el){return !!(el.offsetWidth&&el.offsetHeight&&!el.disabled);});var el=document.activeElement;if(!el||list.indexOf(el)<0){(list[0]||{}).focus&&list[0].focus();return;}var key=e.keyCode||e.which;if((key===37||key===39)&&(el.tagName==='INPUT')&&el.type!=='range')return;if(key===37||key===39||key===38||key===40){if(el.type==='range')return;e.preventDefault();var a=el.getBoundingClientRect(),ax=a.left+a.width/2,ay=a.top+a.height/2,dir=key===37?'left':key===39?'right':key===38?'up':'down',best=null,bestScore=Infinity;list.forEach(function(b){if(b===el)return;var r=b.getBoundingClientRect(),dx=(r.left+r.width/2)-ax,dy=(r.top+r.height/2)-ay;if(dir==='left'&&dx>=-4||dir==='right'&&dx<=4||dir==='up'&&dy>=-4||dir==='down'&&dy<=4)return;var dist=(dir==='left'||dir==='right')?Math.abs(dx)+Math.abs(dy)*2.1:Math.abs(dy)+Math.abs(dx)*2.1;if(dist<bestScore){best=b;bestScore=dist;}});if(best){best.focus();best.scrollIntoView({block:'nearest'});}}}

function openDiscovery(){setMode('discover');if(!discoveryQuery&&query.value.trim())$('titleQuery').value=query.value.trim();$('titleQuery').focus();}
function setDiscoveryStatus(value){text($('discoveryStatus'),value);}
function searchTitles(){
  var q=TitleSearch.normalizeQuery($('titleQuery').value);
  if(!q){setDiscoveryStatus('Skriv en filmtitel eller serie först.');$('titleQuery').focus();return;}
  discoveryQuery=q;chosenTitle=null;showAllSources=false;$('titleDetail').classList.add('hidden');
  setDiscoveryStatus('Söker i öppna titelregister…');text($('titleResults'),'');
  var req=++discoveryRequest;
  var cacheKey='videocast:title:'+discoveryFilter+':'+q.toLocaleLowerCase();
  try{var cached=JSON.parse(localStorage.getItem(cacheKey)||'null');if(cached&&Date.now()-cached.at<86400000){discoveryResults=cached.results;drawTitleResults();setDiscoveryStatus('Visar tidigare hämtade titelträffar · sökningen sparas i högst 24 timmar.');return;}}catch(e){}
  TitleSearch.search(q,discoveryFilter).then(function(reply){
    if(req!==discoveryRequest||mode!=='discover')return;
    discoveryResults=reply.results;drawTitleResults();
    try{localStorage.setItem(cacheKey,JSON.stringify({at:Date.now(),results:reply.results.slice(0,30)}));}catch(e){}
    var status=discoveryResults.length+' titelträffar från '+reply.sources.join(' och ')+'. Det visar inte var titeln kan spelas.';
    if(reply.errors.length)status+=' Kunde inte hämta: '+reply.errors.join(', ')+'. Du kan ändå söka titeln på videotjänsterna.';
    setDiscoveryStatus(status);
  }).catch(function(){if(req!==discoveryRequest)return;discoveryResults=[];drawTitleResults();setDiscoveryStatus('Ingen kontakt med titelregistren. Du kan ändå söka titeln på videowebbplatserna.');});
}
function makeDiv(cls,value){var e=document.createElement('div');e.className=cls||'';if(value!==undefined)text(e,value);return e;}
function drawTitleResults(){
  var out=$('titleResults');out.textContent='';
  discoveryResults.forEach(function(entry){
    var b=document.createElement('button');b.type='button';b.className='title-card';
    b.appendChild(makeDiv('type',entry.kind==='film'?'Film · Wikipedia':'Serie · TVmaze'));
    b.appendChild(makeDiv('name',entry.title));b.appendChild(makeDiv('year',entry.year||'Utgivningsår okänt'));
    if(entry.summary)b.appendChild(makeDiv('description',entry.summary));
    b.addEventListener('click',function(){selectTitle(entry);});out.appendChild(b);
  });
  // Fully usable even when third-party metadata APIs are down or a title isn't indexed.
  if(discoveryQuery){var fallback=document.createElement('button');fallback.type='button';fallback.className='title-card';
    fallback.appendChild(makeDiv('type','Manuell källsökning'));
    fallback.appendChild(makeDiv('name','Sök efter: '+discoveryQuery));
    fallback.appendChild(makeDiv('description','Välj denna rad om titeln inte finns i listan. Då kan du söka på källorna direkt.'));
    fallback.addEventListener('click',function(){selectTitle({title:discoveryQuery,kind:'okänd',year:'',summary:'',url:'',source:'Egen sökning'});});out.appendChild(fallback);}
}
function selectTitle(entry){chosenTitle=entry;showAllSources=false;renderTitleDetail();$('titleDetail').classList.remove('hidden');$('titleDetail').scrollIntoView({block:'start',behavior:'auto'});$('closeDetail').focus();}
function renderTitleDetail(){
 if(!chosenTitle)return;
 text($('selectedType'),(chosenTitle.kind==='film'?'FILM':chosenTitle.kind==='serie'?'SERIE':'FRI SÖKNING')+(chosenTitle.year?' · '+chosenTitle.year:''));
 text($('selectedTitle'),chosenTitle.title);text($('selectedSummary'),chosenTitle.summary||'Sök titeln direkt på en eller flera källor. Detta är inte en tillgänglighetskontroll.');
 $('openOriginal').disabled=!chosenTitle.url;
 $('showAllSources').textContent=showAllSources?'Visa färre källor':'Visa alla källor ('+catalog.length+')';
 var results=$('sourceResults');results.textContent='';
 var sources=TitleSearch.sortSources(catalog,favs);
 if(!showAllSources)sources=sources.slice(0,12);
 sources.forEach(function(site){
   var card=makeDiv('source-card');
   var labels=makeDiv('');labels.appendChild(makeDiv('source-name',site.title));
   var direct=TitleSearch.directSearch(site,chosenTitle.title);
   labels.appendChild(makeDiv('source-help',direct?'Direktsökning · utbud ej kontrollerat':'Webbplats eller sökresultat · utbud ej kontrollerat'));
   var actions=makeDiv('source-actions');
   var open=document.createElement('button');open.type='button';open.className='button '+(direct?'accent':'dim');
   text(open,direct?'Sök här':'Öppna');open.addEventListener('click',function(){
     var url=direct||site.url;openSite({title:site.title,url:url,category:site.category,description:site.description});
   });actions.appendChild(open);
   if(!direct){var web=document.createElement('button');web.type='button';web.className='button dim';text(web,'Webbsök');
     web.addEventListener('click',function(){var url=TitleSearch.siteWebSearch(site,chosenTitle.title);
       if(url)openSite({title:'Webbsök: '+site.title,url:url,category:site.category,description:'Sökmotor: inte verifierad tillgänglighet'});
     });actions.appendChild(web);}
   card.appendChild(labels);card.appendChild(actions);results.appendChild(card);
 });
}

function setup(){redrawCategories();redrawCatalog();
 document.addEventListener('click',function(e){var b=e.target.closest('[data-filter]');if(!b)return;activeFilter=b.dataset.filter;highlightNavigation();redrawCatalog();$('catalogTitle').scrollIntoView({block:'nearest'});});
 $('openTitleSearch').onclick=openDiscovery;$('openTitleSearchNav').onclick=openDiscovery;
 $('titleBack').onclick=function(){setMode('home');redrawCatalog();$('catalogQuery').focus();};
 $('titleSearchButton').onclick=searchTitles;
 $('titleQuery').addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();searchTitles();}});
 document.querySelectorAll('[data-titlefilter]').forEach(function(b){b.onclick=function(){discoveryFilter=b.dataset.titlefilter;document.querySelectorAll('[data-titlefilter]').forEach(function(x){x.classList.toggle('selected',x===b);});if(discoveryQuery)searchTitles();};});
 $('closeDetail').onclick=function(){$('titleDetail').classList.add('hidden');chosenTitle=null;$('titleQuery').focus();};
 $('showAllSources').onclick=function(){showAllSources=!showAllSources;renderTitleDetail();};
 $('openOriginal').onclick=function(){if(!chosenTitle||!chosenTitle.url)return;openSite({title:chosenTitle.title+' (information)',url:chosenTitle.url,category:'Titelinformation',description:chosenTitle.source});};
 $('catalogQuery').addEventListener('input',redrawCatalog);$('searchButton').onclick=function(){redrawCatalog();};$('addSiteButton').onclick=addSite;
 $('openPlayerTop').onclick=showPlayer;$('siteBack').onclick=goHome;$('siteBrowser').onclick=launchBrowser;$('siteFallback').onclick=launchBrowser;
 $('siteReload').onclick=function(){if(currentSite)$('siteFrame').src=currentSite.url;};
 $('playerBack').onclick=leavePlayer;$('loadVideo').onclick=loadVideo;$('playPause').onclick=togglePlayback;$('seekBack').onclick=function(){seek(-10);};$('seekForward').onclick=function(){seek(30);};
 $('seekBar').onchange=function(){if(isFinite(video.duration)&&video.duration>0)video.currentTime=(Number(this.value)||0)*video.duration/1000;};
 $('subtitleButton').onclick=function(){refreshSubtitles();$('subtitleModal').classList.remove('hidden');modalOpen=true;$('closeSubtitle').focus();};$('closeSubtitle').onclick=closeSubs;$('addSubtitle').onclick=addSubtitle;
 video.addEventListener('timeupdate',updatePosition);video.addEventListener('loadedmetadata',updatePosition);video.addEventListener('ended',updatePosition);
 video.addEventListener('error',function(){var m='TV:n kunde inte spela strömmen. Prova en annan källa, eller kontrollera codec och åtkomst.';text($('playerNotice'),m);message(m);});
 document.addEventListener('keydown',function(e){var code=e.keyCode||e.which;if(code===461||code===27||e.key==='Escape'){e.preventDefault();goBack();return;}if(mode==='player'&&(code===415||code===19||code===413)){e.preventDefault();if(code===413)video.pause();else togglePlayback();return;}spatialKey(e);});
 $('catalogQuery').focus();
 document.addEventListener('webOSLaunch',function(e){try{var p=e.detail&&e.detail.params||{};if(p.mediaUrl){showPlayer();$('videoUrl').value=p.mediaUrl;loadVideo();}}catch(err){}});
}
setup();
})();
