/* Global film/series metadata lookup. Works on webOS 6 / Chromium 79.
 * TVmaze (CC BY-SA) + Wikipedia (API), no credentials, no bypassing access controls.
 * Never claims a source actually has the title available. */
(function(root){
  'use strict';
  var endpoints={
    tv:'https://api.tvmaze.com/search/shows?q=',
    film:'https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrnamespace=0&gsrlimit=18&prop=extracts%7Cpageimages&exintro=1&explaintext=1&exsentences=2&piprop=thumbnail&pithumbsize=170&format=json&origin=*&gsrsearch='
  };
  function clean(s){return String(s||'').replace(/<[^>]*>/g,'').replace(/\s+/g,' ').trim();}
  function year(s){var m=String(s||'').match(/\b(18\d\d|19\d\d|20\d\d)\b/);return m?m[1]:'';}
  function normalizeQuery(s){return clean(s).slice(0,110);}
  function parseSeries(raw){
    return (Array.isArray(raw)?raw:[]).slice(0,20).map(function(rec){
      var p=rec&&rec.show||{}, pic=p.image||{};
      return {id:'tvmaze:'+String(p.id||p.name),kind:'serie',title:clean(p.name),year:year(p.premiered),summary:clean(p.summary).slice(0,280),image:pic.medium||'',url:p.url||'',source:'TVmaze'};
    }).filter(function(p){return !!p.title;});
  }
  function parseFilms(raw){
    var pages=raw&&raw.query&&raw.query.pages||{};
    return Object.keys(pages).map(function(id){var p=pages[id];var description=clean(p.extract).slice(0,380);var name=clean(p.title);
      var filmSignal=/\b(film|movie|cinema|motion picture|documentary|feature film|short film)\b/i.test(name+' '+description);
      var disambig=/\((\d{4} )?(film|movie|documentary)\)/i.test(name);
      return {id:'wikipedia:'+id,kind:'film',title:name,year:year(name)||year(description),summary:description.slice(0,280),image:p.thumbnail&&p.thumbnail.source||'',url:'https://en.wikipedia.org/?curid='+id,source:'Wikipedia',score:typeof p.index==='number'?p.index:999,filmSignal:filmSignal||disambig};
    }).filter(function(p){return !!p.title&&p.filmSignal;}).sort(function(a,b){return a.score-b.score;}).slice(0,15);
  }
  function dedupe(results){var keys={};return results.filter(function(x){var k=x.kind+':'+x.title.toLocaleLowerCase()+':'+x.year;if(keys[k])return false;keys[k]=true;return true;});}
  function directSearch(site,query){
    var host='';try{host=new URL(site.url).hostname.replace(/^www\./,'').toLowerCase();}catch(e){return null;}
    var q=encodeURIComponent(normalizeQuery(query));
    if(host==='watch.plex.tv')return 'https://watch.plex.tv/search?query='+q;
    if(host==='youtube.com')return 'https://www.youtube.com/results?search_query='+q;
    if(host==='archive.org')return 'https://archive.org/search?query='+q;
    if(host==='vimeo.com')return 'https://vimeo.com/search?q='+q;
    if(host==='dailymotion.com')return 'https://www.dailymotion.com/search/'+q+'/videos';
    return null;
  }
  function siteWebSearch(site,query){
    var host='';try{host=new URL(site.url).hostname;}catch(e){return '';}
    return 'https://www.google.com/search?q='+encodeURIComponent('site:'+host+' '+normalizeQuery(query));
  }
  function sortSources(sites,favs){return sites.slice().filter(function(s){return !!s.title&&!!s.url;}).sort(function(a,b){
    var ap=favs.indexOf(a.url)>=0?0:1,bp=favs.indexOf(b.url)>=0?0:1;if(ap!==bp)return ap-bp;
    var ad=directSearch(a,'x')?0:1,bd=directSearch(b,'x')?0:1;if(ad!==bd)return ad-bd;
    return a.title.localeCompare(b.title,'sv');
  });}
  function fetchJson(url,timeout){
    var ctrl=typeof AbortController==='function'?new AbortController():null;
    var timer=ctrl?setTimeout(function(){ctrl.abort();},timeout||10000):null;
    return fetch(url,ctrl?{signal:ctrl.signal,credentials:'omit'}:{credentials:'omit'}).then(function(r){
      if(!r.ok)throw new Error('HTTP '+r.status);return r.json();
    }).then(function(j){if(timer)clearTimeout(timer);return j;},function(err){if(timer)clearTimeout(timer);throw err;});
  }
  function search(q,filter){
    q=normalizeQuery(q);if(!q)return Promise.resolve({results:[],sources:[],errors:[]});
    var requests=[];
    if(filter!=='film')requests.push(fetchJson(endpoints.tv+encodeURIComponent(q),12000).then(function(x){return {results:parseSeries(x),source:'TVmaze'};},function(){return {results:[],source:'TVmaze',error:true};}));
    if(filter!=='serie')requests.push(fetchJson(endpoints.film+encodeURIComponent(q+' film'),12000).then(function(x){return {results:parseFilms(x),source:'Wikipedia'};},function(){return {results:[],source:'Wikipedia',error:true};}));
    return Promise.all(requests).then(function(records){
      var results=[],errors=[],sources=[];records.forEach(function(x){sources.push(x.source);if(x.error)errors.push(x.source);else results=results.concat(x.results);});
      results=dedupe(results).sort(function(a,b){var aa=a.title.toLocaleLowerCase(),bb=b.title.toLocaleLowerCase(),needle=q.toLocaleLowerCase();
        var as=aa===needle?0:aa.indexOf(needle)===0?1:2,bs=bb===needle?0:bb.indexOf(needle)===0?1:2;return as-bs;});
      return {results:results,sources:sources,errors:errors};
    });
  }
  var api={search:search,parseSeries:parseSeries,parseFilms:parseFilms,dedupe:dedupe,directSearch:directSearch,siteWebSearch:siteWebSearch,sortSources:sortSources,normalizeQuery:normalizeQuery};
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.VideoCastTitleSearch=api;
})(this);
