# Video Cast TV 0.2 – LG OLED65C14LB (webOS 6 / Chromium 79) – fristående LG webOS-app

## Vad den gör

Denna app kan öppnas direkt på LG-TV:n **utan mobilen**. Den ger en fjärrkontrollvänlig TV-katalog med webbplatser hämtade från den tidigare Video Cast/FMHY-katalogen plus några öppna videotjänster. Du kan söka **titlar från Wikipedia (filmer) och TVmaze (serier)**, eller söka **webbplatser/kategorier**, bläddra, skapa favoriter, se senast besökta och lägga till egna webbplatsadresser. När du öppnar en webbplats kan du försöka använda den i den inbyggda inramade vyn; om webbplatsen blockerar inbäddning kan du starta TV:ns officiella webbläsare direkt med en knapp. Där använder du webbplatsens **egen film- och seriesökning**, precis som i mobilappens webbvy.

Inbyggd direktströmsspelare: öppna en vanlig HTTPS-videolänk, pausa/spola och välj eventuella undertextspår (eller lägg till en extern WebVTT-länk). Videon avkodas med de format/codecs som TV-modellen redan stöder; detta paket lägger **inte** till en fristående FFmpeg-dekoder och kan inte kringgå DRM, CORS, inloggningar eller anti-hotlink.

## Begränsningar

- **Sök filmer & serier** ger gemensamma metadata-träffar från Wikipedia och TVmaze; träffarna är inte tillgänglighetskontroller. Därefter får du direktsökning hos tjänster med kända sökadresser (Plex, YouTube, Internet Archive, Vimeo och Dailymotion), eller kan öppna andra källor för manuell sökning. Webbsök använder Google site:-sökning och bekräftar inte uppspelning.
- Wikipedia och TVmaze är externa tjänster och kräver internet direkt på TV:n. TVmaze-data är CC BY-SA – källan anges i resultatraderna. När externa API:er inte fungerar kan du alltid välja **Manuell källsökning** och söka titeln vidare hos en källa.
- Andra webbplatser kan blockera `<iframe>` med X-Frame-Options/CSP. Då är **Öppna i LG-webbläsaren** det avsedda alternativet. Den externa webbläsaren har egna popup- och uppspelningsregler.
- TV-webbappen kan inte fånga upp alla ström-URL:er inuti andra domäners iframe på grund av same-origin-skyddet. För den inbyggda direktströmsspelaren måste strömmens URL vara känd/tillgänglig.
- Webbsidan som öppnas kan behöva Magic Remote-pekaren, inte bara pilknapparna.
- Funktionstest på fysisk LG-TV återstår. Kompatibilitet beror på TV-modell och webOS-version.
- Använd tjänster och material som du har tillåtelse att titta på.

## Installera `.ipk` i utvecklarläge

1. På LG-TV:n: installera **Developer Mode** från LG Content Store (om tillgängligt på din modell). Logga in på ett kostnadsfritt LG Developer-konto, aktivera Dev Mode och slå på Key Server enligt LG:s instruktioner.
2. På datorn: installera Node.js och `npm install -g @webos-tools/cli`. Ställ in profil: `ares-config --profile tv`.
3. Kör `ares-setup-device` och lägg till din TV:s IP-adress, port `9922` och användarnamn `prisoner`.
4. Kör `ares-novacom --device myTV --getkey` och ange lösenfrasen från TV:ns Developer Mode-app.
5. Installera: `ares-install -d myTV com.videocast.tv_0.2.0_all.ipk` (anpassa filvägen).
6. Starta: `ares-launch -d myTV com.videocast.tv`. Appen ska också synas i TV:ns launcher så länge utvecklarläget är aktivt.

LG:s steg: https://webostv.developer.lge.com/develop/getting-started/developer-mode-app

## Bygg själv

```sh
node tests/catalog.test.js
npm install --no-save @webos-tools/cli@3.2.6
# Kopiera webOSTV.js från det officiella CLI-paketets basic-template till app/webOSTV.js
npx ares-package --no-minify -o dist ./app
```

GitHub Actions-workflowet gör detta automatiskt och publicerar en `.ipk` under Artifacts.

## Senare integration med Android

Mobilappen fungerar fortsatt separat som LG/Chromecast-castklient. Denna TV-app behöver den inte. Att få Android-appen att starta **just TV-appen** med en videolänk kräver att vi bygger en separat mottagar-/parkopplingslösning eller en stödd webOS startparameterintegration; det ingår inte i 0.1.
