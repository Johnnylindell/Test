package com.example.lgembeddedcast;

import org.junit.Test;
import static org.junit.Assert.*;

public class VideoCandidateTest {
    @Test public void detectsSimpleMedia() {
        assertEquals(VideoCandidate.Kind.MP4, VideoCandidate.from("https://cdn.example.org/m.mp4?a=2", "", "t", "video", false).kind);
        assertEquals(VideoCandidate.Kind.HLS, VideoCandidate.from("https://cdn.example.org/master.m3u8", "", "t", "network", false).kind);
        assertEquals(VideoCandidate.Kind.WEBM, VideoCandidate.from("https://cdn.example.org/v.webm", "", "t", "video", false).kind);
    }
    @Test public void embeddedYouTubeOnly() {
        assertEquals("dQw4w9WgXcQ", VideoCandidate.from("https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ", "", "", "iframe", true).youtubeId);
        assertNull(VideoCandidate.from("https://www.youtube.com/embed/dQw4w9WgXcQ", "", "", "iframe", false));
    }
    @Test public void rejectsUnsafeAndNonVideo() {
        assertNull(VideoCandidate.from("blob:https://example.com/x", "", "", "", false));
        assertNull(VideoCandidate.from("javascript:alert(1)", "", "", "", false));
        assertNull(VideoCandidate.from("https://example.org/film.mp4.jpg", "", "", "", false));
        assertNull(VideoCandidate.from("https://example.org/watch", "", "", "", false));
    }
}
