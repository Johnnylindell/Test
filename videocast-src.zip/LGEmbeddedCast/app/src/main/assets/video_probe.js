(function() {
  if (window.__lgCastProbeInstalled) { window.__lgCastScan && window.__lgCastScan(); return; }
  window.__lgCastProbeInstalled = true;
  const seen = new Set();
  function report(url, mime, source, iframe) {
    if (!url || typeof url !== 'string' || url.startsWith('blob:') || url.startsWith('data:')) return;
    try {
      const absolute = new URL(url, document.baseURI).href;
      const id = (iframe ? 'iframe:' : 'media:') + absolute;
      if (seen.has(id)) return;
      seen.add(id);
      window.AndroidMedia.found(JSON.stringify({
        url: absolute, mime: mime || '', source: source || 'HTML video',
        title: document.title || 'Inbäddad video', iframe: !!iframe
      }));
    } catch (_) { }
  }
  function scan(root) {
    try {
      (root || document).querySelectorAll('video').forEach(video => {
        report(video.currentSrc, video.type || '', 'Videospelare', false);
        report(video.getAttribute('src'), video.type || '', 'Videospelare', false);
        video.querySelectorAll('source').forEach(source => report(source.src, source.type || '', 'Videokälla', false));
      });
      (root || document).querySelectorAll('source').forEach(source => {
        if (source.closest('video')) report(source.src, source.type || '', 'Videokälla', false);
      });
      (root || document).querySelectorAll('iframe').forEach(frame => {
        report(frame.src, '', 'Inbäddad YouTube', true);
        try { if (frame.contentDocument) scan(frame.contentDocument); } catch (_) { /* cross-origin */ }
      });
    } catch (_) { }
  }
  window.__lgCastScan = () => scan(document);
  scan(document);
  new MutationObserver(() => scan(document)).observe(document.documentElement || document, {
    subtree: true, childList: true, attributes: true,
    attributeFilter: ['src', 'type']
  });
  setInterval(() => scan(document), 2500);
})();
