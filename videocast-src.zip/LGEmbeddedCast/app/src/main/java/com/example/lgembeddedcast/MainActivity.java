package com.example.lgembeddedcast;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.mediarouter.app.MediaRouteButton;

import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Browser + embedded video detector + LG webOS and Chromecast casting (no mirroring). */
public final class MainActivity extends Activity implements LgWebOsClient.Listener {
    private static final int BG = Color.rgb(13, 20, 32);
    private static final int PANEL = Color.rgb(24, 35, 50);
    private static final int PANEL_LIGHT = Color.rgb(35, 49, 68);
    private static final int ACCENT = Color.rgb(87, 204, 246);
    private static final int WHITE = Color.rgb(242, 247, 251);
    private static final int MUTED = Color.rgb(149, 168, 188);

    private FrameLayout root;
    private LinearLayout pageLayout;
    private WebView browser;
    private EditText address;
    private TextView status;
    private TextView mediaHeader;
    private LinearLayout mediaRows;
    private Button tvButton;
    private MediaRouteButton chromecastButton;
    private ChromecastController chromecast;
    private VideoCandidate waitingForChromecast;
    private enum CastTarget { NONE, LG, CHROMECAST }
    private CastTarget castTarget = CastTarget.NONE;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;
    private LgWebOsClient tvClient;
    private final LinkedHashMap<String, VideoCandidate> media = new LinkedHashMap<>();
    private final LinkedHashMap<String, TvDiscovery.Device> tvs = new LinkedHashMap<>();
    private String probeJavaScript;
    private volatile String lastPageTitle = "Inbäddad video";
    private VideoCandidate pendingSelection;
    private boolean scanning;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        tvClient = new LgWebOsClient(this, this);
        loadProbe();
        buildUI();
        setupBrowser();
        try {
            chromecast = new ChromecastController(this, chromecastButton, new ChromecastController.Listener() {
                @Override public void onSessionReady() {
                    castTarget = CastTarget.CHROMECAST;
                    setStatus("Chromecast ansluten. Välj en video och tryck Casta.");
                    VideoCandidate queued = waitingForChromecast;
                    waitingForChromecast = null;
                    if (queued != null) sendToChromecast(queued);
                }
                @Override public void onSessionEnded() {
                    if (castTarget == CastTarget.CHROMECAST) castTarget = CastTarget.NONE;
                    waitingForChromecast = null;
                    setStatus("Chromecast frånkopplad.");
                }
                @Override public void onStatus(String message) { setStatus(message); }
            });
            if (chromecast.isConnected()) castTarget = CastTarget.CHROMECAST;
        } catch (RuntimeException | LinkageError error) {
            // Google Play services may be absent on some Android devices. LG casting still works.
            chromecastButton.setVisibility(View.GONE);
            setStatus("Google Cast är inte tillgängligt på den här telefonen. LG webOS fungerar fortfarande.");
        }
        handleShare(getIntent());
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES}, 20);
        } else {
            scanTvs();
        }
    }

    @Override public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShare(intent);
    }

    private void buildUI() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                root.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        }
        pageLayout = new LinearLayout(this);
        pageLayout.setOrientation(LinearLayout.VERTICAL);
        root.addView(pageLayout, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        LinearLayout head = row();
        head.setPadding(dp(12), dp(8), dp(12), dp(6));
        head.setBackgroundColor(BG);
        TextView logo = text("▣  VIDEO CAST", 16, ACCENT, true);
        head.addView(logo, new LinearLayout.LayoutParams(0, dp(43), 1));
        logo.setGravity(Gravity.CENTER_VERTICAL);
        tvButton = button("LG-TV", true);
        tvButton.setOnClickListener(v -> { castTarget = CastTarget.LG; showTvPicker(); });
        head.addView(tvButton, new LinearLayout.LayoutParams(-2, dp(40)));
        chromecastButton = new MediaRouteButton(this);
        chromecastButton.setContentDescription("Välj Chromecast eller Google Cast-TV");
        LinearLayout.LayoutParams castParams = new LinearLayout.LayoutParams(dp(48), dp(44));
        castParams.leftMargin = dp(5);
        head.addView(chromecastButton, castParams);
        pageLayout.addView(head);

        LinearLayout nav = row();
        nav.setPadding(dp(8), dp(4), dp(8), dp(6));
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.addView(iconButton("‹", v -> { if (browser.canGoBack()) browser.goBack(); }));
        nav.addView(iconButton("›", v -> { if (browser.canGoForward()) browser.goForward(); }));
        address = new EditText(this);
        address.setTextColor(WHITE);
        address.setHintTextColor(MUTED);
        address.setTextSize(14);
        address.setSingleLine(true);
        address.setPadding(dp(11), 0, dp(6), 0);
        address.setHint("Skriv eller klistra in en webbadress");
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setBackground(round(PANEL_LIGHT, 12));
        address.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);
        address.setOnEditorActionListener((v, action, event) -> { navigate(); return true; });
        nav.addView(address, new LinearLayout.LayoutParams(0, dp(43), 1));
        nav.addView(iconButton("→", v -> navigate()));
        nav.addView(iconButton("↻", v -> browser.reload()));
        pageLayout.addView(nav);

        status = text("Öppna en webbsida med inbäddad video.", 12, MUTED, false);
        status.setPadding(dp(15), dp(2), dp(12), dp(9));
        pageLayout.addView(status);

        browser = new WebView(this);
        browser.setBackgroundColor(Color.rgb(255, 255, 255));
        pageLayout.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.VERTICAL);
        footer.setBackgroundColor(BG);
        footer.setPadding(dp(12), dp(10), dp(12), dp(8));
        LinearLayout summary = row();
        mediaHeader = text("HITTADE VIDEOR  ·  0", 13, WHITE, true);
        mediaHeader.setGravity(Gravity.CENTER_VERTICAL);
        summary.addView(mediaHeader, new LinearLayout.LayoutParams(0, dp(36), 1));
        Button test = button("Testvideo", false);
        test.setOnClickListener(v -> openDemo());
        summary.addView(test, new LinearLayout.LayoutParams(-2, dp(35)));
        footer.addView(summary);

        ScrollView mediaScroll = new ScrollView(this);
        mediaScroll.setFillViewport(false);
        mediaRows = new LinearLayout(this);
        mediaRows.setOrientation(LinearLayout.VERTICAL);
        mediaScroll.addView(mediaRows, new ScrollView.LayoutParams(-1, -2));
        footer.addView(mediaScroll, new LinearLayout.LayoutParams(-1, dp(124)));
        refreshMediaRows();

        LinearLayout actions = row();
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(0, dp(5), 0, 0);
        TextView label = text("TV-KONTROLL", 11, MUTED, true);
        actions.addView(label, new LinearLayout.LayoutParams(0, dp(37), 1));
        actions.addView(smallAction("▶", () -> remotePlayback("Play")));
        actions.addView(smallAction("Ⅱ", () -> remotePlayback("Pause")));
        actions.addView(smallAction("■", () -> remotePlayback("Stop")));
        footer.addView(actions);
        pageLayout.addView(footer);
    }

    private void setupBrowser() {
        WebSettings s = browser.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(browser, true); // required by some embedded players
        browser.addJavascriptInterface(new BrowserBridge(), "AndroidMedia");
        browser.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                media.clear();
                refreshMediaRows();
                if (url != null && url.startsWith("http")) address.setText(url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                lastPageTitle = view.getTitle() == null ? "Inbäddad video" : view.getTitle();
                injectProbe();
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (request != null && request.getUrl() != null) {
                    VideoCandidate video = VideoCandidate.from(request.getUrl().toString(), "", lastPageTitle,
                            "Nätverksström", false);
                    if (video != null) runOnUiThread(() -> addCandidate(video));
                }
                return null; // observe only; never block, redirect or modify website media
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl() == null ? "" : request.getUrl().getScheme();
                return !("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress == 100) injectProbe();
            }
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullscreenView != null) { callback.onCustomViewHidden(); return; }
                fullscreenView = view;
                fullscreenCallback = callback;
                pageLayout.setVisibility(View.GONE);
                root.addView(view, new FrameLayout.LayoutParams(-1, -1));
            }
            @Override public void onHideCustomView() { hideFullscreen(); }
            @Override public void onPermissionRequest(PermissionRequest request) {
                request.deny(); // video playback needs neither camera nor microphone permission
            }
        });
        showWelcome();
    }

    private final class BrowserBridge {
        @JavascriptInterface public void found(String json) {
            try {
                JSONObject obj = new JSONObject(json);
                VideoCandidate video = VideoCandidate.from(obj.optString("url"), obj.optString("mime"),
                        obj.optString("title"), obj.optString("source"), obj.optBoolean("iframe"));
                if (video != null) runOnUiThread(() -> addCandidate(video));
            } catch (Exception ignored) { }
        }
    }

    private void addCandidate(VideoCandidate candidate) {
        if (media.containsKey(candidate.key()) || media.size() >= 30) return;
        media.put(candidate.key(), candidate);
        refreshMediaRows();
    }

    private void refreshMediaRows() {
        if (mediaRows == null) return;
        mediaRows.removeAllViews();
        if (mediaHeader != null) mediaHeader.setText("HITTADE VIDEOR  ·  " + media.size());
        if (media.isEmpty()) {
            TextView help = text("Starta videon på sidan. MP4/HLS och stödda inbäddningar visas här.", 12, MUTED, false);
            help.setPadding(dp(9), dp(12), dp(9), dp(7));
            mediaRows.addView(help);
            return;
        }
        int count = 0;
        for (VideoCandidate video : media.values()) {
            if (++count > 15) break;
            LinearLayout item = row();
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(10), dp(7), dp(8), dp(7));
            item.setBackground(round(PANEL, 9));
            LinearLayout names = new LinearLayout(this);
            names.setOrientation(LinearLayout.VERTICAL);
            String title = video.title.length() > 55 ? video.title.substring(0, 55) + "…" : video.title;
            names.addView(text(title, 12, WHITE, true));
            names.addView(text(video.prettyKind() + "  •  " + video.source, 11, MUTED, false));
            item.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
            Button cast = button("Casta  ↗", true);
            cast.setOnClickListener(v -> castVideo(video));
            item.addView(cast, new LinearLayout.LayoutParams(-2, dp(37)));
            LinearLayout.LayoutParams margin = new LinearLayout.LayoutParams(-1, -2);
            margin.bottomMargin = dp(5);
            mediaRows.addView(item, margin);
        }
    }

    private void loadProbe() {
        try (InputStream in = getAssets().open("video_probe.js")) {
            java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
            byte[] chunk = new byte[4096];
            int length;
            while ((length = in.read(chunk)) != -1) bytes.write(chunk, 0, length);
            probeJavaScript = new String(bytes.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) { probeJavaScript = ""; }
    }
    private void injectProbe() {
        if (browser != null && probeJavaScript != null && !probeJavaScript.isEmpty())
            browser.evaluateJavascript(probeJavaScript, null);
    }

    private void showWelcome() {
        String html = "<!DOCTYPE html><html lang='sv'><meta name='viewport' content='width=device-width, initial-scale=1'>" +
                "<style>body{background:#101925;color:#f2f8ff;font:16px sans-serif;margin:0;padding:26px;}" +
                "h1{font-size:27px;} .step{background:#203145;padding:17px;border-radius:14px;margin:14px 0;}" +
                "small{color:#a7bbcd;} b{color:#66cffa;}</style>" +
                "<h1>Casta bara videon, inte skärmen.</h1>" +
                "<div class='step'><b>1.</b> Öppna en webbsida med inbäddad video.</div>" +
                "<div class='step'><b>2.</b> Välj <b>LG-TV</b> eller tryck på Cast-symbolen för <b>Chromecast</b>.</div>" +
                "<div class='step'><b>3.</b> Starta videon på sidan och tryck sedan på <b>Casta</b>.</div>" +
                "<small>Det är bara videon som skickas – ingen skärmspegling. " +
                "Direktströmmar fungerar bäst; DRM och videor som kräver inloggningscookies kan vara begränsade.</small></html>";
        browser.loadDataWithBaseURL("https://example.org", html, "text/html", "UTF-8", null);
    }

    private void openDemo() {
        String html = "<!DOCTYPE html><html lang='sv'><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<style>body{background:#0c1422;color:white;font:16px sans-serif;margin:22px}video{width:100%;border-radius:12px}</style>" +
                "<h2>Test: fri MP4-video</h2><p>Tryck på uppspelning. Videon ska dyka upp i listan under webbläsaren.</p>" +
                "<video controls playsinline src='https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4'></video>" +
                "<p>Källa: MDN, CC0-exempel.</p></html>";
        browser.loadDataWithBaseURL("https://example.org", html, "text/html", "UTF-8", null);
    }

    private void navigate() {
        String input = address.getText().toString().trim();
        if (input.isEmpty()) return;
        if (!input.matches("(?i)^https?://.*")) input = "https://" + input;
        try {
            java.net.URI uri = new java.net.URI(input);
            if (uri.getHost() == null) throw new IllegalArgumentException();
            browser.loadUrl(uri.toASCIIString());
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(address.getWindowToken(), 0);
            address.clearFocus();
        } catch (Exception e) { Toast.makeText(this, "Ogiltig webbadress", Toast.LENGTH_SHORT).show(); }
    }

    private void handleShare(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (shared == null) return;
        Matcher matcher = Pattern.compile("https?://[^\\s<>'\"]+").matcher(shared);
        if (matcher.find()) {
            String url = matcher.group().replaceAll("[.,;]+$", "");
            if (browser != null) { address.setText(url); navigate(); }
        }
    }

    private void scanTvs() {
        if (scanning) return;
        scanning = true;
        setStatus("Söker efter LG-TV. Chromecast hittas via Cast-knappen …");
        TvDiscovery.scan(this, new TvDiscovery.Listener() {
            @Override public void onTv(TvDiscovery.Device tv) {
                TvDiscovery.Device old = tvs.get(tv.ip);
                if (old == null || tv.avTransportUrl != null || !tv.name.startsWith("LG webOS")) tvs.put(tv.ip, tv);
                setStatus(tvs.size() + " LG-TV hittades. Tryck på Välj TV.");
            }
            @Override public void onDone(String error) {
                scanning = false;
                if (error != null) setStatus(error);
                else if (tvs.isEmpty()) setStatus("Ingen TV hittades. Ange TV:ns IP-adress via Välj TV.");
                else setStatus("Hittade " + tvs.size() + " LG-TV. Välj en för parkoppling.");
            }
        });
    }

    private void showTvPicker() {
        boolean haveCurrent = tvClient.device() != null;
        String[] options = new String[tvs.size() + (haveCurrent ? 3 : 2)];
        int i = 0;
        for (TvDiscovery.Device d : tvs.values()) options[i++] = "▣  " + d.name + " (" + d.ip + ")";
        options[i++] = "↻  Sök efter LG-TV igen";
        options[i++] = "+  Ange IP-adress manuellt";
        if (haveCurrent) options[i] = "×  Glöm parkoppling till aktuell TV";
        new AlertDialog.Builder(this).setTitle("Välj LG webOS-TV")
                .setItems(options, (dialog, which) -> {
                    if (which < tvs.size()) {
                        TvDiscovery.Device tv = tvs.values().toArray(new TvDiscovery.Device[0])[which];
                        castTarget = CastTarget.LG;
                        tvButton.setText("LG: " + tv.ip);
                        tvClient.connect(tv);
                    } else if (which == tvs.size()) {
                        tvs.clear();
                        scanTvs();
                    } else if (which == tvs.size() + 1) {
                        showManualIpDialog();
                    } else if (tvClient.device() != null) {
                        String ip = tvClient.device().ip;
                        tvClient.forgetPairing(ip);
                        tvClient.disconnect();
                        tvButton.setText("Välj TV");
                        setStatus("Parkopplingen är glömd. Anslut igen för att parkoppla på nytt.");
                    }
                }).setNegativeButton("Avbryt", null).show();
    }

    /** One video list serves both devices; the last explicitly selected target wins. */
    private void castVideo(VideoCandidate video) {
        if (castTarget == CastTarget.CHROMECAST && chromecast != null && chromecast.isConnected()) {
            sendToChromecast(video);
        } else if (castTarget == CastTarget.LG && tvClient.device() != null) {
            sendToLg(video);
        } else if (chromecast != null && chromecast.isConnected() && tvClient.device() == null) {
            castTarget = CastTarget.CHROMECAST;
            sendToChromecast(video);
        } else if (tvClient.device() != null && (chromecast == null || !chromecast.isConnected())) {
            castTarget = CastTarget.LG;
            sendToLg(video);
        } else {
            chooseTarget(video);
        }
    }

    private void chooseTarget(VideoCandidate video) {
        String[] choices = chromecast == null
                ? new String[] { "LG webOS-TV" }
                : new String[] { "Chromecast / Google Cast-TV", "LG webOS-TV" };
        new AlertDialog.Builder(this).setTitle("Casta video till")
                .setItems(choices, (dialog, selected) -> {
                    if (chromecast != null && selected == 0) {
                        castTarget = CastTarget.CHROMECAST;
                        if (video.kind == VideoCandidate.Kind.YOUTUBE) {
                            Toast.makeText(this, "YouTube-inbäddningar kräver YouTubes egen Cast-knapp.", Toast.LENGTH_LONG).show();
                            return;
                        }
                        waitingForChromecast = video;
                        // A cancelled picker must not cause this video to start on a later session.
                        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                            if (waitingForChromecast == video) waitingForChromecast = null;
                        }, 60_000);
                        if (chromecast.isConnected()) {
                            waitingForChromecast = null;
                            sendToChromecast(video);
                        } else if (!chromecastButton.performClick()) {
                            waitingForChromecast = null;
                            setStatus("Tryck på Cast-symbolen längst upp och välj din Chromecast.");
                        }
                    } else {
                        castTarget = CastTarget.LG;
                        if (tvClient.device() == null) {
                            pendingSelection = video;
                            showTvPicker();
                        } else sendToLg(video);
                    }
                }).setNegativeButton("Avbryt", null).show();
    }

    private void sendToLg(VideoCandidate video) {
        tvClient.cast(video);
        pauseBrowserVideo();
    }

    private void sendToChromecast(VideoCandidate video) {
        if (chromecast != null && chromecast.cast(video)) pauseBrowserVideo();
    }

    private void pauseBrowserVideo() {
        if (browser != null) browser.evaluateJavascript(
                "(function(){document.querySelectorAll('video').forEach(v=>v.pause());})()", null);
    }

    private void remotePlayback(String action) {
        if (castTarget == CastTarget.CHROMECAST && chromecast != null && chromecast.isConnected()) {
            chromecast.playback(action);
        } else if (castTarget == CastTarget.LG && tvClient.device() != null) {
            tvClient.playback(action);
        } else if (chromecast != null && chromecast.isConnected()) {
            castTarget = CastTarget.CHROMECAST;
            chromecast.playback(action);
        } else if (tvClient.device() != null) {
            castTarget = CastTarget.LG;
            tvClient.playback(action);
        } else {
            setStatus("Välj en LG-TV eller Chromecast först.");
        }
    }

    private void showManualIpDialog() {
        EditText ip = new EditText(this);
        ip.setSingleLine();
        ip.setInputType(InputType.TYPE_CLASS_PHONE);
        ip.setHint("192.168.1.50");
        ip.setPadding(dp(20), dp(15), dp(20), dp(15));
        new AlertDialog.Builder(this).setTitle("TV:ns lokala IP-adress")
                .setView(ip).setNegativeButton("Avbryt", null)
                .setPositiveButton("Anslut", (dialog, which) -> {
                    String host = ip.getText().toString().trim();
                    if (!TvDiscovery.isLocalAddress(host)) {
                        Toast.makeText(this, "Ange en privat IPv4-adress på ditt Wi-Fi", Toast.LENGTH_LONG).show();
                        return;
                    }
                    TvDiscovery.Device tv = new TvDiscovery.Device(host, "LG-TV " + host, null);
                    tvs.put(host, tv);
                    castTarget = CastTarget.LG;
                    tvButton.setText("LG: " + host);
                    tvClient.connect(tv);
                }).show();
    }

    private void setStatus(String s) { runOnUiThread(() -> { if (status != null) status.setText(s); }); }
    @Override public void onStatus(String s) { setStatus(s); }
    @Override public void onConnected(TvDiscovery.Device tv) {
        runOnUiThread(() -> {
            castTarget = CastTarget.LG;
            tvButton.setText("✓ LG");
            if (pendingSelection != null) {
                VideoCandidate candidate = pendingSelection;
                pendingSelection = null;
                tvClient.cast(candidate);
                browser.evaluateJavascript("(function(){document.querySelectorAll('video').forEach(v=>v.pause());})()", null);
            }
        });
    }
    @Override public void onCastResult(boolean ok, String message) {
        runOnUiThread(() -> {
            setStatus(message);
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        });
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == 20) scanTvs();
    }

    private void hideFullscreen() {
        if (fullscreenView == null) return;
        root.removeView(fullscreenView);
        fullscreenView = null;
        pageLayout.setVisibility(View.VISIBLE);
        if (fullscreenCallback != null) fullscreenCallback.onCustomViewHidden();
        fullscreenCallback = null;
    }
    @Override public void onBackPressed() {
        if (fullscreenView != null) hideFullscreen();
        else if (browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }
    @Override public void onDestroy() {
        if (chromecast != null) chromecast.close();
        tvClient.disconnect();
        if (browser != null) { browser.stopLoading(); browser.destroy(); }
        super.onDestroy();
    }

    private int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + .5f); }
    private LinearLayout row() { LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); return r; }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextColor(color); v.setTextSize(sp);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        return d;
    }
    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(12);
        b.setTextColor(primary ? BG : WHITE);
        b.setBackground(round(primary ? ACCENT : PANEL_LIGHT, 10));
        b.setPadding(dp(13), 0, dp(13), 0);
        b.setMinWidth(0); b.setMinimumWidth(0);
        b.setMinHeight(0); b.setMinimumHeight(0);
        return b;
    }
    private View iconButton(String icon, View.OnClickListener callback) {
        TextView v = text(icon, 25, WHITE, false);
        v.setGravity(Gravity.CENTER);
        v.setOnClickListener(callback);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(37), dp(43)));
        return v;
    }
    private View smallAction(String label, Runnable run) {
        Button b = button(label, false);
        b.setTextSize(18);
        b.setOnClickListener(v -> run.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(48), dp(36));
        params.leftMargin = dp(7);
        b.setLayoutParams(params);
        return b;
    }
}
