package com.example.lgembeddedcast;

import android.content.Context;

import androidx.mediarouter.app.MediaRouteButton;

import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.framework.CastButtonFactory;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManager;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;

/** Cast Application Framework (CAF) sender: Chromecast handles its own discovery and connection. */
public final class ChromecastController {
    public interface Listener {
        void onSessionReady();
        void onSessionEnded();
        void onStatus(String message);
    }

    private final Listener listener;
    private final SessionManager sessionManager;
    private final SessionManagerListener<CastSession> sessionListener = new SessionManagerListener<CastSession>() {
        @Override public void onSessionStarting(CastSession session) { listener.onStatus("Ansluter till Chromecast …"); }
        @Override public void onSessionStarted(CastSession session, String sessionId) { listener.onSessionReady(); }
        @Override public void onSessionStartFailed(CastSession session, int error) {
            listener.onStatus("Chromecast-anslutningen misslyckades (" + error + ").");
            listener.onSessionEnded();
        }
        @Override public void onSessionSuspended(CastSession session, int reason) {
            listener.onStatus("Chromecast-anslutningen avbröts.");
        }
        @Override public void onSessionResuming(CastSession session, String sessionId) { }
        @Override public void onSessionResumed(CastSession session, boolean wasSuspended) { listener.onSessionReady(); }
        @Override public void onSessionResumeFailed(CastSession session, int error) {
            listener.onStatus("Kunde inte återansluta till Chromecast.");
            listener.onSessionEnded();
        }
        @Override public void onSessionEnding(CastSession session) { }
        @Override public void onSessionEnded(CastSession session, int error) { listener.onSessionEnded(); }
    };

    /** Call on the main thread after the media route button is attached to the view hierarchy. */
    public ChromecastController(Context context, MediaRouteButton button, Listener listener) {
        this.listener = listener;
        CastContext castContext = CastContext.getSharedInstance(context);
        sessionManager = castContext.getSessionManager();
        CastButtonFactory.setUpMediaRouteButton(context.getApplicationContext(), button);
        sessionManager.addSessionManagerListener(sessionListener, CastSession.class);
    }

    public boolean isConnected() {
        CastSession session = sessionManager.getCurrentCastSession();
        return session != null && session.isConnected() && session.getRemoteMediaClient() != null;
    }

    /** Returns false if there is no active session or the URL is not a directly playable video URL. */
    public boolean cast(VideoCandidate video) {
        if (video.kind == VideoCandidate.Kind.YOUTUBE) {
            listener.onStatus("En YouTube-inbäddning är ingen direkt videolänk för Chromecast. Öppna videon i YouTube och använd dess Cast-knapp.");
            return false;
        }
        RemoteMediaClient client = client();
        if (client == null) {
            listener.onStatus("Anslut till Chromecast via Cast-knappen först.");
            return false;
        }
        String mime;
        switch (video.kind) {
            case HLS: mime = "application/vnd.apple.mpegurl"; break;
            case WEBM: mime = "video/webm"; break;
            case MP4:
            default: mime = "video/mp4"; break;
        }
        MediaMetadata metadata = new MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE);
        metadata.putString(MediaMetadata.KEY_TITLE, video.title);
        MediaInfo info = new MediaInfo.Builder(video.url)
                .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
                .setContentType(mime)
                .setMetadata(metadata)
                .build();
        try {
            client.load(new MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).build())
                    .setResultCallback(result -> listener.onStatus(result.getStatus().isSuccess()
                            ? "Videon skickades till Chromecast."
                            : "Chromecast kunde inte starta videon: " + result.getStatus().getStatusMessage()));
            return true;
        } catch (Exception e) {
            listener.onStatus("Chromecast-fel: " + e.getMessage());
            return false;
        }
    }

    public void playback(String action) {
        RemoteMediaClient client = client();
        if (client == null) {
            listener.onStatus("Ingen aktiv Chromecast-session.");
            return;
        }
        try {
            if ("Play".equals(action)) client.play();
            else if ("Pause".equals(action)) client.pause();
            else if ("Stop".equals(action)) client.stop();
        } catch (Exception e) { listener.onStatus("Chromecast-fel: " + e.getMessage()); }
    }

    private RemoteMediaClient client() {
        CastSession session = sessionManager.getCurrentCastSession();
        return session == null || !session.isConnected() ? null : session.getRemoteMediaClient();
    }

    public void close() {
        sessionManager.removeSessionManagerListener(sessionListener, CastSession.class);
        // Do NOT end the Cast session when the Activity is destroyed: casting can continue on the TV.
    }
}
