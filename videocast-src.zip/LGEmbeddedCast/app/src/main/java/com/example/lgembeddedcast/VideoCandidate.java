package com.example.lgembeddedcast;

import java.net.URI;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** A media resource found in the page; never a browser tab or screen-mirror target. */
public final class VideoCandidate {
    public enum Kind { MP4, HLS, WEBM, YOUTUBE }
    public final String url;
    public final Kind kind;
    public final String title;
    public final String source;
    public final String youtubeId;

    private VideoCandidate(String url, Kind kind, String title, String source, String youtubeId) {
        this.url = url;
        this.kind = kind;
        this.title = title == null || title.trim().isEmpty() ? "Video" : title.trim();
        this.source = source == null ? "Webbsida" : source;
        this.youtubeId = youtubeId;
    }

    public static VideoCandidate from(String url, String mimeHint, String title, String source,
                                       boolean iframeEmbed) {
        if (url == null || url.length() > 8192) return null;
        try {
            URI uri = new URI(url.trim());
            String scheme = uri.getScheme();
            if (scheme == null || !(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))) return null;
            if (uri.getUserInfo() != null || uri.getHost() == null) return null;
            String host = uri.getHost().toLowerCase(Locale.ROOT);
            if (iframeEmbed && (host.equals("youtube.com") || host.endsWith(".youtube.com")
                    || host.equals("youtube-nocookie.com") || host.endsWith(".youtube-nocookie.com"))) {
                String path = uri.getPath();
                Matcher m = Pattern.compile("^/(?:embed|shorts)/([a-zA-Z0-9_-]{11})(?:/|$)").matcher(path);
                if (m.find()) {
                    String id = m.group(1);
                    return new VideoCandidate("https://www.youtube.com/watch?v=" + id, Kind.YOUTUBE,
                            title, source, id);
                }
            }
            String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
            String mime = mimeHint == null ? "" : mimeHint.toLowerCase(Locale.ROOT).trim();
            Kind kind;
            if (path.endsWith(".m3u8") || mime.contains("mpegurl") || mime.contains("x-mpegurl")) {
                kind = Kind.HLS;
            } else if (path.endsWith(".mp4") || path.endsWith(".m4v") || path.endsWith(".mov")
                    || mime.startsWith("video/mp4") || mime.startsWith("video/quicktime")) {
                kind = Kind.MP4;
            } else if (path.endsWith(".webm") || mime.startsWith("video/webm")) {
                kind = Kind.WEBM;
            } else {
                return null;
            }
            return new VideoCandidate(uri.toASCIIString(), kind, title, source, null);
        } catch (Exception e) {
            return null;
        }
    }

    public String key() { return kind + ":" + url; }
    public String prettyKind() {
        switch (kind) {
            case MP4: return "MP4";
            case HLS: return "HLS / m3u8";
            case WEBM: return "WebM";
            case YOUTUBE: return "YouTube";
            default: return "Video";
        }
    }
    public String dlnaMime() {
        switch (kind) {
            case HLS: return "application/vnd.apple.mpegurl";
            case WEBM: return "video/webm";
            default: return "video/mp4";
        }
    }
}
