# Video Cast — LG webOS + Chromecast (v0.2)

An Android browser that casts **embedded video content only** to either an **LG webOS TV** or a **Google Cast receiver** (Chromecast, Chromecast with Google TV, or a compatible Google Cast built-in TV). This is **not** screen mirroring: the receiving device requests and plays the media URL directly.

## Features

- Built-in WebView with address bar, back/forward, reload, and fullscreen video support.
- Discovers direct **MP4, WebM and HLS/m3u8** resources in HTML `<video>`/`<source>` elements and media network requests.
- Finds embedded YouTube video IDs from `youtube.com/embed/…` or `youtube-nocookie.com/embed/…` and launches the LG YouTube app (when installed).
- Lists found videos and casts a selected video with one tap.
- Scans the LAN for LG webOS TVs using SSDP; supports manual local IPv4 entry.
- Includes the official **Google Cast sender SDK (23.0.0)** and its standard Cast device picker; no manual Chromecast IP or sideloaded receiver is needed.
- The same detected MP4/WebM/HLS list plays on either LG webOS or Chromecast.
- Casts to the Google-hosted **Default Media Receiver** with metadata and video-specific MIME types (no receiver registration required).
- Cast target selection persists during the app session; most recently connected/selected receiver controls the video and transport buttons.
- Pairs over webOS SSAP WebSocket (secure port 3001; older-device port 3000 fallback) and remembers the client key.
- Invokes the LG native media player with the direct video URL; optionally falls back to DLNA/AVTransport if advertised in discovery.
- Playback buttons: play / pause / stop.
- Accepts *Share > LG Video Cast* for URLs shared from another Android browser.
- Contains an openly accessible sample video test page. No tracker, accounts, backend or paid APIs.

## Requirements

- Android 8.0+ (min SDK 26), JDK 17 + Android Studio for building.
- LG TV running webOS with network remote/pairing functionality available **or** a Chromecast / Google Cast built-in receiver.
- Google Cast requires a phone with functional Google Play services.
- Phone and TV on the **same Wi-Fi/LAN**; turn the TV on and accept the pairing request on the TV.
- The TV must support the video codecs/container/stream format, and the media URL must be directly reachable from the TV.

## How to build

### GitHub Actions (easiest to get an APK)

Upload project contents to a **new repository**, push to `main`, and use the included `.github/workflows/build-apk.yml` workflow. It builds and tests on GitHub-hosted `ubuntu-latest`, not on your PC or any self-hosted runner. Download `LGEmbeddedCast-debug-apk` from the successful run's artifacts and install `app-debug.apk` on your Android phone.

### Android Studio on Windows

1. Unzip and open the `LGEmbeddedCast` folder in Android Studio.
2. Install Android SDK Platform 35 and JDK 17 if prompted.
3. Open PowerShell in the project folder and run `powershell -ExecutionPolicy Bypass -File .\bootstrap-gradle.ps1`. This initializes the missing Gradle wrapper and builds the debug APK. For a command-line build after that, use `./gradlew.bat assembleDebug`.
4. Find `app/build/outputs/apk/debug/app-debug.apk`.

### macOS / Linux

With JDK 17 and Android SDK installed, run `./bootstrap-gradle.sh`; the APK is at the same path.

**Why a bootstrap script?** The wrapper binary JAR is not bundled in the source-only distribution. The script fetches an official Gradle release, generates the standard wrapper, then builds. GitHub Actions does not require this script.

## Usage

1. Open the app, allow the *Nearby devices* permission if asked.
2. To use **LG webOS**, tap **LG-TV**, choose your television or enter its local IPv4 address, and accept the pairing prompt on the TV.
3. To use **Chromecast / Google Cast**, tap the Cast icon in the upper-right corner and select the receiver through Google's device picker. (If neither device was selected, tapping **Casta** beside a video also prompts for LG or Chromecast.)
4. Enter a webpage containing an embedded video, and play it briefly if nothing is detected.
5. Tap **Casta** beside the detected video. The last selected target receives the **video URL only**, not the browser screen. Playback buttons at the bottom control that target.
6. If a page does not detect anything, try **Testvideo** to verify casting with an unprotected MP4. For testing Chromecast choose an unprotected MP4 first.
7. To switch output while both LG and Chromecast are connected, tap **LG-TV** and reselect LG, or choose Chromecast through the Cast icon. The selected target will be used for subsequent casts.

## Important limitations

- DRM-protected streaming (e.g. Widevine/PlayReady), EME, `blob:` URLs, MSE buffers and encrypted content cannot be extracted or bypassed.
- An iframe hosted on a different origin cannot be inspected directly by page JavaScript. Network URL observation can still find some of its media requests, but **not every website is supported**.
- The TV does not inherit browser cookies, authorization headers, signed sessions or CORS state. Streams requiring those will usually fail to play directly. No cookie-relay/proxy is implemented.
- YouTube launching varies by installed LG TV app and may require selecting a YouTube profile on the TV before playback starts. **The Chromecast default receiver does NOT support casting YouTube watch pages or iframe URLs**; open the video in YouTube and use the YouTube Cast control.
- Google Cast may reject streams that the receiver cannot decode; it cannot inherit browser cookies or private request headers.
- Chromecast sessions use Google Cast SDK device discovery. Chromecast is not scanned by the manual LG SSDP code, and its IP address cannot be entered manually.
- LG webOS media-player IDs, media codecs, HLS handling and DLNA capabilities vary by TV model/firmware. A command being accepted by webOS is not proof playback started.
- This is a v0.2 source implementation and **has not been built into an APK or tested on actual LG/Chromecast hardware in the current environment**. Source/manifest inspections and local tests are not substitutes for a full Android Gradle build and device testing.
- **TV settings:** Some models require "LG Connect Apps" or "Mobile TV On" enabled in network settings for pairing to appear.
- The app uses a custom TLS trust manager for LG's self-signed SSAP certificate, scoped to the private-LAN TV WebSocket client. This does not alter HTTPS validation used by Android WebView. For a production distribution, replace with TV-certificate pinning / pairing-bound verification.
- Android 17 apps targeting API 37+ require `ACCESS_LOCAL_NETWORK`. This app currently targets API 35; update manifest and runtime permission logic if raising the target.

## Source layout

- `MainActivity.java` — web browser, interface, video list, share intent and user actions.
- `video_probe.js` — DOM video / embedded iframe detection.
- `VideoCandidate.java` — strict HTTP(S) media URL classifier.
- `TvDiscovery.java` — SSDP / LG TV discovery and optional DLNA service metadata.
- `LgWebOsClient.java` — webOS SSAP session, pairing, app launch and remote controls.
- `ChromecastOptionsProvider.java` — Google-hosted Default Media Receiver configuration.
- `ChromecastController.java` — Google Cast device sessions, play, pause, stop, and direct media loading.
- `DlnaController.java` — optional DLNA fallback.
- `VideoCandidateTest.java` — JUnit regression tests.

## License / intended use

Personal experimental project. Use only content you have the right to stream. The app does not remove copy protection or bypass access controls.

## Cast-specific technical notes

- `play-services-cast-framework:23.0.0` is the Google Cast Android Sender SDK released October 19, 2026.
- Chromecast uses its own system device-selection dialog and does **not** share the LG webOS IP/pairing protocol.
- The Chromecast receiver directly fetches the original HTTP(S) video URL. Browser tabs, frames, cookies, DRM keys and the phone screen are never sent.
- If your phone has no Google Play services, the Google Cast button is unavailable, but LG webOS remains available.
- If a source only provides iframe links (such as a YouTube embed), the Chromecast Default Media Receiver cannot play them: the app intentionally rejects these as non-direct URLs.

Official docs: https://developers.google.com/cast/docs/android_sender/integrate and https://developers.google.com/cast/docs/web_receiver .
