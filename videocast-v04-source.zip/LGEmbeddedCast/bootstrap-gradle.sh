#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
GRADLE_VERSION=8.10.2
CACHE="${TMPDIR:-/tmp}/lgembeddedcast-gradle"
DIST="$CACHE/gradle-$GRADLE_VERSION/bin/gradle"
if [ ! -x "$DIST" ]; then
  mkdir -p "$CACHE"
  curl -fL "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$CACHE/gradle.zip"
  unzip -q -o "$CACHE/gradle.zip" -d "$CACHE"
fi
"$DIST" wrapper --gradle-version "$GRADLE_VERSION"
./gradlew :app:testDebugUnitTest :app:assembleDebug
printf 'APK: app/build/outputs/apk/debug/app-debug.apk\n'
