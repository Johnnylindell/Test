# One-time Windows Gradle wrapper bootstrap. Requires JDK 17 and internet.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$version = '8.10.2'
$cache = Join-Path $env:TEMP 'LGEmbeddedCast-gradle'
$zip = Join-Path $cache "gradle-$version-bin.zip"
$gradle = Join-Path $cache "gradle-$version\bin\gradle.bat"
New-Item -ItemType Directory -Force -Path $cache | Out-Null
if (!(Test-Path $gradle)) {
    Write-Host 'Hämtar Gradle 8.10.2 …'
    Invoke-WebRequest "https://services.gradle.org/distributions/gradle-$version-bin.zip" -OutFile $zip
    Expand-Archive -Path $zip -DestinationPath $cache -Force
}
& $gradle wrapper --gradle-version $version
if ($LASTEXITCODE -ne 0) { throw 'Gradle wrapper kunde inte skapas' }
& .\gradlew.bat :app:testDebugUnitTest :app:assembleDebug
if ($LASTEXITCODE -ne 0) { throw 'Android-bygget misslyckades' }
Write-Host 'APK: app\build\outputs\apk\debug\app-debug.apk'
