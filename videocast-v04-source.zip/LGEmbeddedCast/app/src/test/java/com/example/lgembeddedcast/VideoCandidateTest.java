package com.example.lgembeddedcast;

import org.junit.Test;
import static org.junit.Assert.*;

public class VideoCandidateTest {
    private VideoCandidate v(String url, String mime) {
        return VideoCandidate.from(url, mime, "Test", "Player", false);
    }
    @Test public void acceptsBasicFormats() {
        assertEquals(VideoCandidate.Kind.MP4, v("https://cdn.example/file.mp4?token=x", "").kind);
        assertEquals(VideoCandidate.Kind.HLS, v("https://cdn.example/manifest.m3u8", "").kind);
        assertEquals(VideoCandidate.Kind.DASH, v("https://cdn.example/manifest.mpd", "").kind);
        assertEquals(VideoCandidate.Kind.WEBM, v("https://cdn.example/file.webm", "").kind);
        assertEquals(VideoCandidate.Kind.MKV, v("https://cdn.example/file.mkv", "").kind);
        assertEquals(VideoCandidate.Kind.MPEG_TS, v("https://cdn.example/video.ts", "").kind);
    }
    @Test public void recognizesExtensionlessWithMime() {
        assertEquals(VideoCandidate.Kind.HLS,
                v("https://cdn.example/api/stream/abc123", "application/vnd.apple.mpegurl").kind);
        assertEquals(VideoCandidate.Kind.DASH,
                v("https://cdn.example/api/stream/xyz", "application/dash+xml").kind);
        assertEquals(VideoCandidate.Kind.MP4,
                v("https://cdn.example/v?id=123", "video/mp4").kind);
    }
    @Test public void doesNotTreatPageOrBlobAsVideo() {
        assertNull(v("https://example.com/watch/123", "text/html"));
        assertNull(v("blob:https://example.com/uuid", "video/mp4"));
        assertNull(v("javascript:alert(1)", "video/mp4"));
    }
    @Test public void recognizesQueryFileNames() {
        assertEquals(VideoCandidate.Kind.MP4,
                v("https://cdn.example/download?filename=sample.mp4", "").kind);
    }
    @Test public void rejectsCredentials() {
        assertNull(v("https://user:password@cdn.example/video.mp4", ""));
    }
}
