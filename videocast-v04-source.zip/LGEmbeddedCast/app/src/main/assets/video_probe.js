(function () {
  'use strict';
  if (window.__lgCastProbeInstalled) {
    if (window.__lgCastScan) window.__lgCastScan();
    return;
  }
  window.__lgCastProbeInstalled = true;
  var seen = new Set();
  var extensions = /\.(?:m3u8|mpd|mp4|m4v|mov|webm|mkv|ts|m2ts)(?:[?#]|$)/i;
  var mediaTypes = /(?:video\/(?:mp4|webm|quicktime|x-matroska|mp2t)|application\/(?:vnd\.apple\.mpegurl|x-mpegurl|dash\+xml))/i;
  function report(url, mime, source, iframe) {
    if (!url || typeof url !== 'string' || /^(blob:|data:|javascript:)/i.test(url)) return;
    try {
      var absolute = new URL(url, document.baseURI).href;
      if (!/^https?:/i.test(absolute)) return;
      if (!extensions.test(absolute) && !mediaTypes.test(mime || '') && !(iframe && /(?:youtube\.com|youtube-nocookie\.com)/i.test(absolute))) return;
      if (seen.has(absolute) || seen.size > 300) return;
      seen.add(absolute);
      window.AndroidMedia.found(JSON.stringify({
        url: absolute, mime: mime || '', source: source || 'Webbspelare',
        title: document.title || 'Inbäddad video', iframe: !!iframe
      }));
    } catch (_) { /* no access to bridge or invalid URL */ }
  }
  function scan() {
    if (!document.documentElement) return;
    try {
      document.querySelectorAll('video').forEach(function (video) {
        report(video.currentSrc, video.getAttribute('type') || '', 'Aktiv videospelare');
        report(video.getAttribute('src'), video.getAttribute('type') || '', 'Videoelement');
        video.querySelectorAll('source').forEach(function (source) {
          report(source.src, source.type || '', 'Videokälla');
        });
      });
      document.querySelectorAll('source').forEach(function (source) {
        report(source.src, source.type || '', 'Videokälla');
      });
      // Cross-origin iframes get their own early probe via AndroidX WebKit.
      document.querySelectorAll('iframe[src]').forEach(function(frame) {
        if (/youtube\.com|youtube-nocookie\.com/i.test(frame.src))
          report(frame.src, '', 'Inbäddad YouTube', true);
      });
    } catch (_) { }
  }
  window.__lgCastScan = scan;
  document.addEventListener('DOMContentLoaded', scan, { once: true });
  ['play', 'loadedmetadata', 'loadstart', 'playing'].forEach(function (type) {
    document.addEventListener(type, scan, true);
  });
  function beginObserving() {
    if (!document.documentElement) return;
    scan();
    new MutationObserver(scan).observe(document.documentElement, {
      subtree: true, childList: true, attributes: true,
      attributeFilter: ['src', 'type']
    });
  }
  if (document.documentElement) beginObserving();
  else document.addEventListener('DOMContentLoaded', beginObserving, { once: true });

  // Capture HLS/DASH manifests fetched by JavaScript-based players, including
  // players that render only a blob: MediaSource video URL. Observe only URLs
  // and public Content-Type values: do not collect tokens, request bodies or headers.
  if (typeof window.fetch === 'function') {
    var oldFetch = window.fetch;
    window.fetch = function () {
      var args = arguments;
      var response = oldFetch.apply(this, args);
      try {
        var requested = args[0] && (typeof args[0] === 'string' ? args[0] : args[0].url);
        Promise.resolve(response).then(function (r) {
          try {
            report((r && r.url) || requested,
              r && r.headers && r.headers.get('content-type') || '', 'Fetch / MSE');
          } catch (_) { }
        }, function () {});
      } catch (_) { }
      return response;
    };
  }
  if (typeof XMLHttpRequest !== 'undefined') {
    var oldOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (method, url) {
      try {
        var xhr = this;
        xhr.addEventListener('loadend', function () {
          try { report(xhr.responseURL || url,
            xhr.getResponseHeader('Content-Type') || '', 'XHR / MSE'); }
          catch (_) { }
        }, { once: true });
      } catch (_) { }
      return oldOpen.apply(this, arguments);
    };
  }
  setInterval(scan, 2000);
})();
