package com.example.lgembeddedcast;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;

/** Finds LG webOS TVs by SSDP. Uses only same-LAN discovery, no cloud service. */
public final class TvDiscovery {
    public interface Listener {
        void onTv(Device device);
        void onDone(String error);
    }

    public static final class Device {
        public final String ip;
        public final String name;
        public final String avTransportUrl;
        public Device(String ip, String name, String avTransportUrl) {
            this.ip = ip;
            this.name = name;
            this.avTransportUrl = avTransportUrl;
        }
    }

    private TvDiscovery() {}

    public static boolean isLocalAddress(String rawIp) {
        try {
            if (!rawIp.matches("[0-9.]{7,15}")) return false; // no DNS / public destinations
            InetAddress addr = InetAddress.getByName(rawIp);
            if (addr.getAddress().length != 4) return false;
            byte[] b = addr.getAddress();
            int a = b[0] & 255, c = b[1] & 255;
            return a == 10 || (a == 172 && c >= 16 && c <= 31)
                    || (a == 192 && c == 168) || (a == 169 && c == 254);
        } catch (Exception e) {
            return false;
        }
    }

    public static void scan(Context context, Listener listener) {
        new Thread(() -> performScan(context, listener), "lg-tv-discovery").start();
    }

    private static void performScan(Context context, Listener listener) {
        Handler main = new Handler(Looper.getMainLooper());
        WifiManager.MulticastLock lock = null;
        String error = null;
        try {
            WifiManager manager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (manager != null) {
                lock = manager.createMulticastLock("lg-video-ssdp");
                lock.setReferenceCounted(false);
                lock.acquire();
            }
            Map<String, String> locations = new LinkedHashMap<>();
            try (DatagramSocket socket = new DatagramSocket()) {
                socket.setSoTimeout(650);
                InetAddress group = InetAddress.getByName("239.255.255.250");
                for (String searchTarget : new String[]{
                        "urn:lge-com:service:webos-second-screen:1",
                        "urn:schemas-upnp-org:device:MediaRenderer:1"}) {
                    String request = "M-SEARCH * HTTP/1.1\r\n" +
                            "HOST: 239.255.255.250:1900\r\n" +
                            "MAN: \"ssdp:discover\"\r\n" +
                            "MX: 2\r\nST: " + searchTarget + "\r\n\r\n";
                    byte[] data = request.getBytes(StandardCharsets.UTF_8);
                    socket.send(new DatagramPacket(data, data.length, group, 1900));
                }
                long deadline = System.currentTimeMillis() + 4500;
                while (System.currentTimeMillis() < deadline) {
                    try {
                        byte[] buf = new byte[8192];
                        DatagramPacket packet = new DatagramPacket(buf, buf.length);
                        socket.receive(packet);
                        String ip = packet.getAddress().getHostAddress();
                        if (!isLocalAddress(ip)) continue;
                        String response = new String(packet.getData(), packet.getOffset(), packet.getLength(), StandardCharsets.UTF_8);
                        String lower = response.toLowerCase(Locale.ROOT);
                        if (!(lower.contains("lge-com:service:webos-second-screen") ||
                                (lower.contains("lg") && (lower.contains("mediarenderer") || lower.contains("webos"))))) continue;
                        String loc = headerValue(response, "location");
                        if (loc != null && !locations.containsKey(ip)) {
                            locations.put(ip, loc);
                            Device basic = new Device(ip, "LG webOS – " + ip, null);
                            main.post(() -> listener.onTv(basic));
                        }
                    } catch (java.net.SocketTimeoutException ignored) { }
                }
            }
            // Fetch presentation names and optional DLNA AVTransport controls.
            for (Map.Entry<String, String> item : locations.entrySet()) {
                Device enriched = enrich(item.getKey(), item.getValue());
                if (enriched != null) main.post(() -> listener.onTv(enriched));
            }
        } catch (SecurityException e) {
            error = "Nätverksbehörighet saknas. Ge appen åtkomst till närliggande enheter.";
        } catch (Exception e) {
            error = "Kan inte söka på lokalt nätverk: " + e.getMessage();
        } finally {
            if (lock != null && lock.isHeld()) lock.release();
        }
        String finalError = error;
        main.post(() -> listener.onDone(finalError));
    }

    private static String headerValue(String response, String key) {
        for (String line : response.split("\\r?\\n")) {
            int i = line.indexOf(':');
            if (i >= 0 && line.substring(0, i).trim().equalsIgnoreCase(key))
                return line.substring(i + 1).trim();
        }
        return null;
    }

    private static Device enrich(String ip, String location) {
        try {
            URI uri = new URI(location);
            if (!"http".equalsIgnoreCase(uri.getScheme()) || !ip.equals(uri.getHost())) return null;
            HttpURLConnection c = (HttpURLConnection) uri.toURL().openConnection();
            c.setConnectTimeout(1800);
            c.setReadTimeout(1800);
            c.setInstanceFollowRedirects(false);
            byte[] data;
            try (java.io.InputStream in = c.getInputStream()) {
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] chunk = new byte[4096];
                int count;
                while (out.size() < 160_000 && (count = in.read(chunk, 0,
                        Math.min(chunk.length, 160_000 - out.size()))) != -1) {
                    out.write(chunk, 0, count);
                }
                data = out.toByteArray();
            }
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
            dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Document doc = dbf.newDocumentBuilder().parse(new ByteArrayInputStream(data));
            String name = findTag(doc.getDocumentElement(), "friendlyName");
            String manufacturer = findTag(doc.getDocumentElement(), "manufacturer");
            if (manufacturer != null && !manufacturer.toLowerCase(Locale.ROOT).contains("lg")) return null;
            String avTransport = null;
            NodeList services = doc.getElementsByTagName("service");
            for (int i = 0; i < services.getLength(); i++) {
                if (!(services.item(i) instanceof Element)) continue;
                Element service = (Element) services.item(i);
                String type = findTag(service, "serviceType");
                if (type != null && type.contains("AVTransport")) {
                    String control = findTag(service, "controlURL");
                    if (control != null) {
                        URI resolved = uri.resolve(control);
                        if ("http".equalsIgnoreCase(resolved.getScheme()) && ip.equals(resolved.getHost()))
                            avTransport = resolved.toString();
                    }
                }
            }
            return new Device(ip, name == null || name.trim().isEmpty() ? "LG webOS – " + ip : name, avTransport);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String findTag(Element root, String tag) {
        NodeList nodes = root.getElementsByTagName(tag);
        return nodes.getLength() == 0 ? null : nodes.item(0).getTextContent().trim();
    }
}
