package com.example.lgembeddedcast;

import android.net.Uri;

import java.util.Locale;

/** Small on-device domain filter; does not promise uBlock Origin parity. */
public final class AdBlocker {
    private static final String[] DOMAINS = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adnxs.com", "taboola.com", "outbrain.com",
        "popads.net", "popcash.net", "propellerads.com", "onclickads.net", "exoclick.com", "exosrv.com",
        "trafficjunky.net", "adsterra.com", "ad-maven.com", "adform.net", "adskeeper.co.uk", "criteo.com",
        "scorecardresearch.com", "quantserve.com", "zedo.com", "pubmatic.com", "rubiconproject.com",
        "smartadserver.com", "casalemedia.com", "bidswitch.net", "revcontent.com", "mgid.com",
        "yieldmanager.com", "openx.net", "3lift.com", "smaato.net", "inmobi.com"
    };
    public static boolean blocks(String url) {
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase(Locale.ROOT);
            for (String domain : DOMAINS) if (host.equals(domain) || host.endsWith("." + domain)) return true;
        } catch (Exception ignored) { }
        return false;
    }
    private AdBlocker() { }
}
