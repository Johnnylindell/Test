package com.example.lgembeddedcast;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/** Only hyperlinks and short labels are cached; never media, login details or copyrighted videos. */
public final class CatalogRepository {
    public static final String FMHY = "https://fmhy.net/video";
    public interface Listener { void onCatalog(List<Entry> entries, String message); }
    public static final class Entry {
        public final String title, url, category, description;
        Entry(String title, String url, String category, String description) {
            this.title = title; this.url = url; this.category = category; this.description = description;
        }
        public String toString() { return title + " — " + category; }
    }
    private static final String PREFS = "catalog_cache_v1";
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler UI = new Handler(Looper.getMainLooper());
    private static final OkHttpClient HTTP = new OkHttpClient.Builder()
            .followRedirects(true).callTimeout(java.time.Duration.ofSeconds(15)).build();

    public static List<Entry> seed(Context ctx) {
        try (InputStream input = ctx.getAssets().open("catalog_seed.json")) {
            byte[] bytes = new byte[input.available()];
            int read = 0; while (read < bytes.length) { int n = input.read(bytes, read, bytes.length - read); if (n < 0) break; read += n; }
            return fromJson(new String(bytes, 0, read, StandardCharsets.UTF_8));
        } catch (Exception error) { return new ArrayList<>(); }
    }
    public static List<Entry> cached(Context ctx) {
        String json = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("entries", "");
        List<Entry> result = fromJson(json);
        return result.size() >= 10 ? result : seed(ctx);
    }
    public static void refresh(Context ctx, Listener listener) {
        IO.execute(() -> {
            try {
                Request req = new Request.Builder().url(FMHY).header("User-Agent", "VideoCast/0.4 (Android catalog reader)").build();
                try (Response response = HTTP.newCall(req).execute()) {
                    if (!response.isSuccessful() || response.body() == null) throw new IllegalStateException("HTTP " + response.code());
                    String html = response.body().string();
                    List<Entry> items = parse(html);
                    if (items.size() < 20) throw new IllegalStateException("FMHY:s katalogstruktur kunde inte läsas");
                    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("entries", toJson(items)).apply();
                    UI.post(() -> listener.onCatalog(items, "FMHY uppdaterad · " + items.size() + " länkar"));
                }
            } catch (Exception error) {
                UI.post(() -> listener.onCatalog(cached(ctx), "Offlinekatalog används – uppdatering misslyckades"));
            }
        });
    }
    /** Parses the actual headings and linked list entries, not user-facing ad/player pages. */
    public static List<Entry> parse(String html) {
        Document doc = Jsoup.parse(html, FMHY);
        Element main = doc.selectFirst("main");
        if (main == null) main = doc.body();
        ArrayList<Entry> result = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        String section = "Video";
        for (Element el : main.select("h2, h3, h4, li")) {
            if (el.is("h2, h3, h4")) {
                String header = el.text().trim();
                if (header.length() > 1 && header.length() < 70) section = header;
                continue;
            }
            // Avoid huge excerpts: short site-level metadata only.
            String detail = el.text().replaceAll("\\s+", " ").trim();
            if (detail.length() > 120) detail = detail.substring(0, 117) + "…";
            for (Element a : el.select("a[href]")) {
                String name = a.text().replaceAll("\\s+", " ").trim();
                String url = a.absUrl("href");
                if (!validSite(name, url)) continue;
                String host;
                try { host = new java.net.URI(url).getHost().toLowerCase(Locale.ROOT); }
                catch (Exception bad) { continue; }
                // One entry per site+path. Mirrors may share a name but differ in host.
                String key = host + a.attr("href");
                if (seen.add(key)) result.add(new Entry(name, url, section, detail));
                if (result.size() >= 1200) return result;
            }
        }
        return result;
    }
    private static boolean validSite(String name, String url) {
        if (name.length() < 3 || name.length() > 75 || url.length() > 1024) return false;
        if (name.matches("(?i)(status|mirror[s]?|[0-9]+|guide|tools?|resources?|download|clones?|backups?|index|home|status page|adblocker|source|faq|extensions?)")) return false;
        try {
            java.net.URI uri = new java.net.URI(url);
            String host = uri.getHost();
            if (!"https".equalsIgnoreCase(uri.getScheme()) || host == null || uri.getUserInfo() != null) return false;
            return !(host.equalsIgnoreCase("fmhy.net") || host.endsWith(".fmhy.net") || host.equalsIgnoreCase("github.com")
                    || host.endsWith(".github.com") || host.equalsIgnoreCase("rentry.co") || host.equalsIgnoreCase("rentry.org"));
        } catch (Exception e) { return false; }
    }
    private static String toJson(List<Entry> items) {
        JSONArray array = new JSONArray();
        try { for (Entry e : items) { JSONObject j = new JSONObject(); j.put("title", e.title); j.put("url", e.url); j.put("category", e.category); j.put("description", e.description); array.put(j); } }
        catch (Exception ignored) { }
        return array.toString();
    }
    private static List<Entry> fromJson(String s) {
        List<Entry> entries = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) {
                JSONObject j = a.getJSONObject(i);
                String url = j.optString("url");
                String name = j.optString("title");
                if (validSite(name, url)) entries.add(new Entry(name, url, j.optString("category", "Video"), j.optString("description")));
            }
        } catch (Exception ignored) { }
        return entries;
    }
}
