package com.example.lgembeddedcast;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/** webOS SSAP control, paired on the TV itself. Never sends an entire browser page. */
public final class LgWebOsClient {
    public interface Listener {
        void onStatus(String status);
        void onConnected(TvDiscovery.Device device);
        void onCastResult(boolean accepted, String message);
    }

    private interface ResponseCallback { void onReply(boolean ok, String error); }

    private final SharedPreferences prefs;
    private final Listener listener;
    private final AtomicInteger ids = new AtomicInteger();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ConcurrentHashMap<String, ResponseCallback> outstanding = new ConcurrentHashMap<>();
    private OkHttpClient httpClient;
    private volatile WebSocket socket;
    private volatile boolean registered;
    private volatile TvDiscovery.Device device;
    private volatile VideoCandidate waitingVideo;
    private volatile boolean isDlnaSession;

    public LgWebOsClient(Context ctx, Listener listener) {
        this.prefs = ctx.getSharedPreferences("lg_keys", Context.MODE_PRIVATE);
        this.listener = listener;
        this.httpClient = newClient();
    }

    public TvDiscovery.Device device() { return device; }
    public void forgetPairing(String ip) { prefs.edit().remove("key_" + ip).apply(); }
    public boolean isConnected() { return registered; }

    public synchronized void connect(TvDiscovery.Device tv) {
        disconnect();
        if (!TvDiscovery.isLocalAddress(tv.ip)) {
            listener.onStatus("TV-adressen måste vara en lokal IPv4-adress.");
            return;
        }
        device = tv;
        listener.onStatus("Ansluter till " + tv.name + " …");
        openSocket(tv, true);
    }

    private void openSocket(TvDiscovery.Device tv, boolean secure) {
        String scheme = secure ? "wss" : "ws";
        String port = secure ? "3001" : "3000";
        Request r = new Request.Builder().url(scheme + "://" + tv.ip + ":" + port + "/").build();
        WebSocket ws = httpClient.newWebSocket(r, new WebSocketListener() {
            @Override public void onOpen(WebSocket webSocket, Response response) {
                if (device != tv) { webSocket.close(1000, "tv changed"); return; }
                socket = webSocket;
                JSONObject payload = new JSONObject();
                try {
                    payload.put("forcePairing", false);
                    payload.put("pairingType", "PROMPT");
                    String key = prefs.getString("key_" + tv.ip, "");
                    if (!key.isEmpty()) payload.put("client-key", key);
                    JSONObject manifest = new JSONObject();
                    manifest.put("manifestVersion", 1);
                    manifest.put("appVersion", "1.0");
                    manifest.put("permissions", new JSONArray()
                            .put("LAUNCH").put("LAUNCH_WEBAPP")
                            .put("CONTROL_INPUT_MEDIA_PLAYBACK").put("READ_RUNNING_APPS"));
                    payload.put("manifest", manifest);
                    JSONObject register = new JSONObject();
                    register.put("type", "register");
                    register.put("id", "register_0");
                    register.put("payload", payload);
                    webSocket.send(register.toString());
                    listener.onStatus(key.isEmpty()
                            ? "Godkänn parkopplingen med TV-fjärrkontrollen."
                            : "Verifierar parkopplingen …");
                } catch (Exception e) { listener.onStatus("Parkopplingsfel: " + e.getMessage()); }
            }

            @Override public void onMessage(WebSocket webSocket, String message) {
                if (device != tv) return;
                try {
                    JSONObject root = new JSONObject(message);
                    String type = root.optString("type");
                    String id = root.optString("id");
                    if ("registered".equals(type)) {
                        String key = root.optJSONObject("payload") == null ? ""
                                : root.optJSONObject("payload").optString("client-key");
                        if (!key.isEmpty()) prefs.edit().putString("key_" + tv.ip, key).apply();
                        registered = true;
                        listener.onConnected(tv);
                        listener.onStatus("Ansluten till " + tv.name);
                        VideoCandidate queued = waitingVideo;
                        waitingVideo = null;
                        if (queued != null) cast(queued);
                    } else if ("error".equals(type) || "response".equals(type)) {
                        ResponseCallback callback = outstanding.remove(id);
                        if (callback != null) {
                            JSONObject body = root.optJSONObject("payload");
                            boolean ok = "response".equals(type) && (body == null || body.optBoolean("returnValue", true));
                            String error = root.optString("error", body == null ? "" : body.optString("errorText", ""));
                            callback.onReply(ok, error);
                        } else if ("error".equals(type) && "register_0".equals(id)) {
                            listener.onStatus("Parkoppling nekades: " + root.optString("error"));
                        }
                    }
                } catch (Exception e) {
                    listener.onStatus("Ogiltigt svar från TV: " + e.getMessage());
                }
            }

            @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                if (device != tv) return;
                if (!registered && secure) {
                    listener.onStatus("Säker anslutning saknas, testar äldre webOS-anslutning …");
                    openSocket(tv, false);
                } else {
                    registered = false;
                    listener.onStatus("TV-anslutning misslyckades: " + t.getMessage());
                }
            }
            @Override public void onClosed(WebSocket webSocket, int code, String reason) {
                if (socket == webSocket) registered = false;
            }
        });
        socket = ws;
    }

    public void cast(VideoCandidate video) {
        TvDiscovery.Device tv = device;
        if (tv == null) {
            listener.onCastResult(false, "Välj en LG-TV först.");
            return;
        }
        if (!registered) {
            waitingVideo = video;
            listener.onStatus("Väntar på parkoppling för att skicka videon …");
            return;
        }
        isDlnaSession = false;
        try {
            if (video.kind == VideoCandidate.Kind.YOUTUBE) {
                JSONObject payload = new JSONObject().put("id", "youtube.leanback.v4")
                        .put("contentId", "v=" + video.youtubeId);
                request("ssap://system.launcher/launch", payload, (ok, err) -> {
                    if (ok) finishCast(true, "", tv, video);
                    else {
                        try {
                            JSONObject alternative = new JSONObject().put("id", "com.webos.app.youtube")
                                    .put("contentId", "v=" + video.youtubeId);
                            request("ssap://system.launcher/launch", alternative,
                                    (secondOk, secondErr) -> finishCast(secondOk, secondErr, tv, video));
                        } catch (Exception e) { finishCast(false, e.getMessage(), tv, video); }
                    }
                });
            } else {
                openMediaViewer(video, tv);
            }
        } catch (Exception e) { listener.onCastResult(false, e.getMessage()); }
    }

    private void openMediaViewer(VideoCandidate video, TvDiscovery.Device tv) throws Exception {
        // Unlike launching the media-discovery APP, this API addresses an actual remote media URL.
        JSONObject payload = new JSONObject().put("target", video.url)
                .put("title", video.title).put("mimeType", video.dlnaMime());
        request("ssap://media.viewer/open", payload, (ok, err) -> {
            if (ok) listener.onCastResult(true, "LG:s Media Viewer tog emot URL:en. Uppspelning och codec behöver fortfarande verifieras på TV:n.");
            else if (tv.avTransportUrl != null) startDlnaOrFallback(video, tv);
            else {
                try { launchNativePlayer(video, tv, "com.webos.app.mediadiscovery", true); }
                catch (Exception e) { listener.onCastResult(false, "LG-mediespelaren svarade fel: " + e.getMessage()); }
            }
        });
    }

    private void startDlnaOrFallback(VideoCandidate video, TvDiscovery.Device tv) {
        listener.onStatus("Försöker spela upp via DLNA …");
        new Thread(() -> {
            try {
                DlnaController.cast(tv.avTransportUrl, video);
                isDlnaSession = true;
                listener.onCastResult(true, "DLNA-kommandot skickat. Om TV:n visar okänt format: prova MP4 (H.264/AAC) eller annan källa.");
            } catch (Exception e) {
                listener.onStatus("DLNA kunde inte spela upp; testar LG:s mediespelare …");
                try { launchNativePlayer(video, tv, "com.webos.app.mediadiscovery", true); }
                catch (Exception other) { listener.onCastResult(false, "DLNA: " + e.getMessage() + "; webOS: " + other.getMessage()); }
            }
        }, "lg-dlna-first").start();
    }

    private void launchNativePlayer(VideoCandidate video, TvDiscovery.Device tv, String appId, boolean allowFallback) throws Exception {
        JSONObject item = new JSONObject()
                .put("fullPath", video.url)
                .put("fileName", video.title)
                .put("mediaType", "VIDEO")
                .put("deviceType", "DMR")
                .put("lastPlayPosition", 0);
        JSONObject payload = new JSONObject()
                .put("id", appId)
                .put("params", new JSONObject().put("payload", new JSONArray().put(item)));
        request("ssap://com.webos.applicationManager/launch", payload, (ok, err) -> {
            if (ok) {
                listener.onCastResult(true, "LG:s spelare tog emot kommandot (inte bekräftad uppspelning). Om TV:n visar okänd fil krävs kompatibel codec och direkt åtkomlig videolänk.");
            } else if (allowFallback) {
                try { launchNativePlayer(video, tv, "com.webos.app.photovideo", false); }
                catch (Exception e) { finishCast(false, e.getMessage(), tv, video); }
            } else {
                finishCast(false, err, tv, video);
            }
        });
    }

    private void finishCast(boolean ok, String error, TvDiscovery.Device tv, VideoCandidate video) {
        if (ok) {
            listener.onCastResult(true, "TV:n accepterade kommandot.");
        } else {
            listener.onCastResult(false, "TV:n accepterade inte videon: " + error);
        }
    }

    public void playback(String action) {
        TvDiscovery.Device tv = device;
        if (tv == null) return;
        if (isDlnaSession && tv.avTransportUrl != null) {
            new Thread(() -> {
                try { DlnaController.control(tv.avTransportUrl, action); listener.onStatus("DLNA: " + action); }
                catch (Exception e) { listener.onStatus("DLNA-fel: " + e.getMessage()); }
            }, "lg-dlna-control").start();
        } else if (registered) {
            String mediaAction = action.equals("Play") ? "play" : action.equals("Pause") ? "pause" : "stop";
            request("ssap://media.controls/" + mediaAction, new JSONObject(), (ok, err) ->
                    listener.onStatus(ok ? "TV: " + mediaAction : "TV-kommando misslyckades: " + err));
        }
    }

    private void request(String uri, JSONObject payload, ResponseCallback callback) {
        WebSocket ws = socket;
        if (ws == null || !registered) { callback.onReply(false, "Ingen TV-anslutning"); return; }
        try {
            String id = "c_" + ids.incrementAndGet();
            JSONObject request = new JSONObject().put("type", "request").put("id", id)
                    .put("uri", uri).put("payload", payload);
            outstanding.put(id, callback);
            main.postDelayed(() -> {
                ResponseCallback expired = outstanding.remove(id);
                if (expired != null) expired.onReply(false, "Inget svar från TV:n inom 12 sekunder");
            }, 12_000);
            if (!ws.send(request.toString())) {
                outstanding.remove(id);
                callback.onReply(false, "WebSocket stängd");
            }
        } catch (Exception e) { callback.onReply(false, e.getMessage()); }
    }

    public synchronized void disconnect() {
        registered = false;
        isDlnaSession = false;
        waitingVideo = null;
        device = null;
        outstanding.clear();
        WebSocket ws = socket;
        socket = null;
        if (ws != null) ws.cancel();
    }

    /** Scope the non-validating SSL trust to the TV's private LAN SSAP channel only. */
    private static OkHttpClient newClient() {
        try {
            X509TrustManager localTvTrust = new X509TrustManager() {
                @Override public void checkClientTrusted(X509Certificate[] chain, String authType) { }
                @Override public void checkServerTrusted(X509Certificate[] chain, String authType) { }
                @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            };
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(null, new TrustManager[]{ localTvTrust }, new SecureRandom());
            return new OkHttpClient.Builder()
                    .connectTimeout(5, TimeUnit.SECONDS)
                    .readTimeout(0, TimeUnit.SECONDS)
                    .pingInterval(25, TimeUnit.SECONDS)
                    .sslSocketFactory(ctx.getSocketFactory(), localTvTrust)
                    .hostnameVerifier((host, session) -> TvDiscovery.isLocalAddress(host))
                    .build();
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
}
