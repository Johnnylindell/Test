package com.example.lgembeddedcast;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;

/** Optional UPnP AVTransport fallback for LG TVs advertising a MediaRenderer. */
public final class DlnaController {
    private DlnaController() {}

    public static void cast(String controlUrl, VideoCandidate video) throws Exception {
        if (video.kind == VideoCandidate.Kind.YOUTUBE) throw new IllegalArgumentException("YouTube kräver TV-appen");
        String xml = "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
                "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
                "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">" +
                "<item id=\"0\" parentID=\"-1\" restricted=\"1\"><dc:title>" +
                xml(video.title) + "</dc:title><upnp:class>object.item.videoItem</upnp:class>" +
                "<res protocolInfo=\"http-get:*:" + video.dlnaMime() + ":*\">" +
                xml(video.url) + "</res></item></DIDL-Lite>";
        send(controlUrl, "SetAVTransportURI", "<InstanceID>0</InstanceID><CurrentURI>" +
                xml(video.url) + "</CurrentURI><CurrentURIMetaData>" + xml(xml) + "</CurrentURIMetaData>");
        send(controlUrl, "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>");
    }

    public static void control(String url, String action) throws Exception {
        if (!(action.equals("Play") || action.equals("Pause") || action.equals("Stop"))) throw new IllegalArgumentException();
        String args = "<InstanceID>0</InstanceID>" + (action.equals("Play") ? "<Speed>1</Speed>" : "");
        send(url, action, args);
    }

    private static String xml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }

    private static void send(String controlUrl, String method, String args) throws Exception {
        URI uri = new URI(controlUrl);
        if (!"http".equalsIgnoreCase(uri.getScheme()) || !TvDiscovery.isLocalAddress(uri.getHost()))
            throw new IllegalArgumentException("Osäker DLNA-adress");
        String envelope = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
                "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                "<s:Body><u:" + method + " xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">" +
                args + "</u:" + method + "></s:Body></s:Envelope>";
        HttpURLConnection conn = (HttpURLConnection) uri.toURL().openConnection();
        conn.setConnectTimeout(3000);
        conn.setReadTimeout(4500);
        conn.setInstanceFollowRedirects(false);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
        conn.setRequestProperty("SOAPACTION", "\"urn:schemas-upnp-org:service:AVTransport:1#" + method + "\"");
        conn.setDoOutput(true);
        byte[] bytes = envelope.getBytes(StandardCharsets.UTF_8);
        try (OutputStream out = conn.getOutputStream()) { out.write(bytes); }
        int status = conn.getResponseCode();
        conn.disconnect();
        if (status < 200 || status >= 300) throw new java.io.IOException("DLNA HTTP " + status);
    }
}
