package com.example.lgembeddedcast;

import android.os.Handler;
import android.os.Looper;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Best-effort diagnostic check: an LG TV or Chromecast fetches the media independently.
 * Never forwards browser cookies, authentication or private session headers.
 */
public final class MediaUrlCheck {
    public interface Listener { void onResult(Result result); }
    public static final class Result {
        public final boolean blocked;
        public final boolean invalid;
        public final String message;
        Result(boolean blocked, boolean invalid, String message) {
            this.blocked = blocked; this.invalid = invalid; this.message = message;
        }
    }
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private MediaUrlCheck() { }

    public static void check(VideoCandidate video, Listener listener) {
        IO.execute(() -> {
            Result result = inspect(video);
            MAIN.post(() -> listener.onResult(result));
        });
    }
    static Result inspect(VideoCandidate video) {
        if (video.kind == VideoCandidate.Kind.YOUTUBE) return new Result(false, false, "");
        HttpURLConnection conn = null;
        try {
            URL url = new URL(video.url);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(3500);
            conn.setReadTimeout(3500);
            conn.setInstanceFollowRedirects(true);
            // Use HEAD first, to avoid downloading the movie on the phone.
            conn.setRequestMethod("HEAD");
            int status = conn.getResponseCode();
            if (status == 405 || status == 501) return new Result(false, false, "HEAD stöds inte; testar på TV:n.");
            if (status == 401 || status == 403) return new Result(true, false,
                    "Videokällan svarar HTTP " + status + " utan webbläsarens inloggning. TV:n kan inte läsa den direkt.");
            if (status >= 400) return new Result(true, false,
                    "Videokällan svarar HTTP " + status + ". Länken kan ha gått ut eller kräva en annan spelare.");
            String mime = conn.getContentType();
            if (mime != null && mime.toLowerCase(java.util.Locale.ROOT).contains("text/html"))
                return new Result(true, true,
                        "Servern returnerar HTML i stället för video. Välj en annan källa/spelare.");
            return new Result(false, false, "");
        } catch (Exception ignored) {
            // Some CDNs deny HEAD or require signed playback. Do not false-block.
            return new Result(false, false, "");
        } finally { if (conn != null) conn.disconnect(); }
    }
}
